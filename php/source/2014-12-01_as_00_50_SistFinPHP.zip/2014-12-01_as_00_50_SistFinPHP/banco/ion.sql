-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23-Nov-2014 às 20:32
-- Versão do servidor: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ion`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `t_categoria`
--

CREATE TABLE IF NOT EXISTS `t_categoria` (
`id_categoria` bigint(20) unsigned NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tipo` varchar(100) CHARACTER SET utf8 NOT NULL,
  `usu_atu` varchar(100) CHARACTER SET utf8 NOT NULL,
  `dh_atu` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Extraindo dados da tabela `t_categoria`
--

INSERT INTO `t_categoria` (`id_categoria`, `nome`, `tipo`, `usu_atu`, `dh_atu`) VALUES
(1, 'ALIMENTACAO', 'DEBITO', 'OPERADOR', '2014-11-01'),
(2, 'ANIMAIS', 'DEBITO', 'OPERADOR', '2014-11-01'),
(4, 'CASA', 'DEBITO', 'OPERADOR', '2014-11-01'),
(6, 'COMPRAS', 'DEBITO', 'OPERADOR', '2014-11-01'),
(8, 'CONTAS', 'DEBITO', 'OPERADOR', '2014-11-01'),
(10, 'EDUCACAO', 'DEBITO', 'OPERADOR', '2014-11-01'),
(12, 'FILHOS', 'DEBITO', 'OPERADOR', '2014-11-01'),
(14, 'SAUDE', 'DEBITO', 'OPERADOR', '2014-11-01'),
(17, 'TRANSPORTE/DESLOCAMENTO', 'DEBITO', 'OPERADOR', '2014-11-01'),
(18, 'DIVERSAO', 'DEBITO', 'OPERADOR', '2014-11-01'),
(20, 'RENDIMENTOS', 'CREDITO', 'OPERADOR', '2014-11-01'),
(21, 'SALARIO/APOSENTADORIA', 'CREDITO', 'OPERADOR', '2014-11-01');

-- --------------------------------------------------------

--
-- Estrutura da tabela `t_movimentacao`
--

CREATE TABLE IF NOT EXISTS `t_movimentacao` (
`id_movimentacao` bigint(20) unsigned NOT NULL,
  `data_movimento` date NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `valor` double NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `usu_atu` varchar(100) NOT NULL,
  `dh_atu` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Extraindo dados da tabela `t_movimentacao`
--

INSERT INTO `t_movimentacao` (`id_movimentacao`, `data_movimento`, `tipo`, `descricao`, `valor`, `categoria_id`, `usu_atu`, `dh_atu`) VALUES
(1, '2014-11-19', 'DEBITO', 'BIFE LIVRE', 12.99, 1, 'WILLIAM', '2014-11-01'),
(2, '2014-11-19', 'DEBITO', 'RACAO DE CACHORRO', 10.99, 2, 'WILLIAM', '2014-11-01'),
(3, '2014-11-19', 'DEBITO', 'PINTURA DA CASA', 13.99, 4, 'WILLIAM', '2014-11-01'),
(4, '2014-11-19', 'DEBITO', 'TENIS MASCULINO', 40.99, 6, 'WILLIAM', '2014-11-01'),
(5, '2014-11-19', 'DEBITO', 'CONTA DE TELEFONE', 30.99, 8, 'WILLIAM', '2014-11-01'),
(6, '2014-11-19', 'DEBITO', 'BOLETO DA FACULDADE', 80.99, 10, 'WILLIAM', '2014-11-01'),
(7, '2014-11-19', 'DEBITO', 'ANIVERSARIO DO FILHO', 60.99, 12, 'WILLIAM', '2014-11-01'),
(8, '2014-11-19', 'DEBITO', 'PLANO DE SAUDE', 60.99, 14, 'WILLIAM', '2014-11-01'),
(9, '2014-11-19', 'DEBITO', 'TRI - PASSAGEM ANTECIPADA', 80.99, 17, 'WILLIAM', '2014-11-01'),
(10, '2014-11-19', 'DEBITO', 'PASSEIO NO PARQUE DE DIVERSOES', 40.99, 18, 'WILLIAM', '2014-11-01'),
(11, '2014-11-19', 'CREDITO', 'REDIMENTOS POUPANCA', 50.99, 20, 'WILLIAM', '2014-11-01'),
(12, '2014-11-19', 'CREDITO', 'SALARIO MENSAL DO APOSENTADO', 500.99, 21, 'WILLIAM', '2014-11-01'),
(13, '2015-02-02', 'DEBITO', 'dsadas', 999.99, 1, 'WILLIAM', '2014-11-23'),
(14, '2015-02-02', 'CREDITO', 'seilad sada', 999.99, 1, 'WILLIAM', '2014-11-23'),
(15, '2015-02-01', 'DEBITO', 'dfdf', 2321, 2, 'WILLIAM', '2014-11-23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `t_usuario`
--

CREATE TABLE IF NOT EXISTS `t_usuario` (
`id_usuario` bigint(20) unsigned NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `usu_atu` varchar(100) NOT NULL,
  `dh_atu` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Extraindo dados da tabela `t_usuario`
--

INSERT INTO `t_usuario` (`id_usuario`, `usuario`, `email`, `senha`, `usu_atu`, `dh_atu`) VALUES
(1, 'admin', 'admin@admin.com.br', '123456', 'CADASTRO', '2014-11-01'),
(2, 'operador', 'operador@admin.com.br', '123456', 'CADASTRO', '2014-11-01'),
(3, 'william', 'william_clarck@hotmail.com', '123456', 'CADASTRO', '2014-11-01'),
(4, 'wilmar', 'wilmar.dupont@gmail.com', '123456', 'CADASTRO', '2014-11-01'),
(47, 'LUCAS', 'wlasda@jdsaidja.com.br', 'vcvcxv', 'CADASTRO', '0000-00-00'),
(52, 'lucdsalmlmdsfds', 'wlasddsfdsfsdfsda@jdsaidja.com.br', 'fdsf', 'CADASTRO', '2013-12-01'),
(55, 'LUCAS2', 'wlasddskjkjfdsfsdfsda@jdsaidja.com.br', 'dsadsa', 'CADASTRO', '2014-11-22'),
(59, 'Franciele', 'rtrtr@dsadujsaud.coim', 'dsadsadsa', 'CADASTRO', '2014-11-22'),
(62, 'WILLIAMCLARCK1', 'william_clarcdsdak@hotmail.com', 'dsadas', 'CADASTRO', '2014-11-23'),
(63, 'WILLIAMCLARCK1da', 'william_clarcdsdcxzak@hotmail.com', 'dsadas', 'CADASTRO', '2014-11-23'),
(64, 'WILLIAMCLARCK1dadf', 'william_clarcdsdcfdxzak@hotmail.com', 'dsadas', 'CADASTRO', '2014-11-23'),
(65, 'ekatrs', 'ekatrs', '123456', 'CADASTRO', '2014-11-23'),
(66, 'DSADSsd', 'dasdsa', 'dsadsa', 'CADASTRO', '2014-11-23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
`id` int(11) unsigned NOT NULL,
  `aprovador` int(11) DEFAULT NULL,
  `endereco_IP` varbinary(16) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha` varchar(80) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `CPF` varchar(11) NOT NULL,
  `data_nascimento` date NOT NULL,
  `perfil` char(1) NOT NULL,
  `curso` int(11) NOT NULL,
  `matricula` varchar(9) NOT NULL,
  `situacao` char(1) NOT NULL,
  `codigo_ativacao` varchar(40) DEFAULT NULL,
  `codigo_senha_esquecida` varchar(40) DEFAULT NULL,
  `tempo_senha_esquecida` int(11) unsigned DEFAULT NULL,
  `codigo_lembranca` varchar(40) DEFAULT NULL,
  `criado_em` int(11) unsigned NOT NULL,
  `ultimo_login` int(11) unsigned DEFAULT NULL,
  `nome` varchar(100) NOT NULL,
  `fone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=105 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `aprovador`, `endereco_IP`, `usuario`, `senha`, `salt`, `email`, `CPF`, `data_nascimento`, `perfil`, `curso`, `matricula`, `situacao`, `codigo_ativacao`, `codigo_senha_esquecida`, `tempo_senha_esquecida`, `codigo_lembranca`, `criado_em`, `ultimo_login`, `nome`, `fone`) VALUES
(1, NULL, 0x7f000001, 'administrator', '59beecdf7fc966e2f17fd8f65a4a9aeb09d4a3d4', '9462e8eee0', 'admin@admin.com', '34433152404', '0000-00-00', '', 0, '', '', '', NULL, NULL, NULL, 1268889823, 1379692193, 'Admin', '0'),
(60, NULL, 0x00000000000000000000000000000001, 'wilmar__dupont', '0ef018530bd7b78605f6f2bfe136c5c5883e3ebe', NULL, 'wilmar.dupont@gmail.com', '00659830094', '1982-08-24', 'G', 0, '1111', 'A', NULL, '9888ea00bc68a114090e60d3424b19c937fdb943', 1385697170, NULL, 1384104473, 1384104473, 'Wilmar Dupont Neto', '5130221047'),
(89, NULL, 0x00000000000000000000000000000001, '', 'a9d0de4ae0eb2c8bf1bfa3a5a8d8af51f44c3eae', NULL, 'doctor@rey.com', '16665155587', '2007-01-31', 'P', 0, '3344', 'I', '4dbc3bcc1f7625c0b08d453d721fb73df6fec5af', NULL, NULL, NULL, 1391140415, 1391140415, 'Robert Rey', '5555555555'),
(104, NULL, 0x00000000000000000000000000000001, 'ekatrs', '', NULL, 'william_clarck@hotmail.com', '01862853029', '1988-05-05', '0', 0, '0', 'I', 'a047551df05c7f63598b08bce95f02422be881a6', NULL, NULL, NULL, 1414617808, 1414617808, 'William Pacheco', '5133333333');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_categoria`
--
ALTER TABLE `t_categoria`
 ADD PRIMARY KEY (`id_categoria`), ADD UNIQUE KEY `id_categoria` (`id_categoria`), ADD UNIQUE KEY `nome` (`nome`);

--
-- Indexes for table `t_movimentacao`
--
ALTER TABLE `t_movimentacao`
 ADD PRIMARY KEY (`id_movimentacao`), ADD UNIQUE KEY `id_movimentacao` (`id_movimentacao`);

--
-- Indexes for table `t_usuario`
--
ALTER TABLE `t_usuario`
 ADD PRIMARY KEY (`id_usuario`), ADD UNIQUE KEY `id_usuario` (`id_usuario`), ADD UNIQUE KEY `usuario` (`usuario`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `usuario_2` (`usuario`,`email`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `CPF` (`CPF`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_categoria`
--
ALTER TABLE `t_categoria`
MODIFY `id_categoria` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `t_movimentacao`
--
ALTER TABLE `t_movimentacao`
MODIFY `id_movimentacao` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `t_usuario`
--
ALTER TABLE `t_usuario`
MODIFY `id_usuario` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=105;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
