<?php include_once('../model/m_util.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Pagina Login</title>
</head>

<body>


<div align="center"><img src="../img/logo.png" width="153" height="69"  alt=""/>
</div>

<p align="center">Sistema Financeiro</p>
<p align="center">Gerenciador Pessoal de Finanças</p>
<div class="conteudo" border="1">
<p align="center">Acesse ou Registre-se</p>
<hr>

  <form action="../controller/c_login.php" method="post" name="form1" id="form1">
    <p align="center">
	<label>Usuario ou E-mail: </label><br>
      <input name="user" type="text" id="user" placeholder="Usuario ou E-mail" required>
    </p>
    <p align="center">
	<label>Senha: </label><br>
      <input name="pw" type="password" id="pw" placeholder="Senha" required>
    </p>
    <p align="center">
    <!--  
     <input type="checkbox" name="checkbox" id="checkbox">
      <label for="checkbox">Lembrar de Mim   </label>
    -->
      <input type="submit" name="Acessar" id="Acessar" value="Acessar">
    </p>
    <hr>
  </form>
  
  <div class="rodape"> 
    <div align="center">
    <a href="v_recuperar.php">Esqueci minha senha</a>  
     <a href="v_registrar.php">Quero Registrar</a>
     </div>
  </div>
  
</div>

</body>
</html>
