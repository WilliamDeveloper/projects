<?php include_once('../model/m_util.php'); ?>
<?php include_once('../model/m_conexao.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/script_jq.js"></script>
<title>Pagina Movimentacao</title>
<script>
$(document).ready(function(){
$('#tipo').on('change', function(){
    var tipo = this.value;
    $('#categoria').val("");
    $('#categoria option').each(function(){
        var $this = $(this);
        if($this.data('tipo') == tipo) $this.show();
        else $this.hide();
    });	
});

$('#data').blur(function(){
		var x = $(this).val();
		//alert(x);
		var RegExp_ = /^(1[9][0-9][0-9]|2[0][0-9][0-9])[- / .]([1-9]|0[1-9]|1[0-2])[- / .]([1-9]|0[1-9]|1[0-9]|2[0-9]|3[0-1])$/;
		//alert("oi");
		if(RegExp_.test(x)==false){
		    alert("Digite a data no formato valido");
		    $(this).focus();
		}
});

$('#descricao').blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[^\s]+[a-z0-9 ]+$/;
		//alert("oi");
		if(RegExp_.test(x)==false){
		    alert("Digite somente letras minusculas de a-z \n e numero de 0-9 e espaço");
		    $(this).focus();
		}
});

$('#valor').blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$/;
		//alert("oi");
		if(RegExp_.test(x)==false){
		    alert("Somente numero de 0 a 9");
		    $(this).focus();
		}
});

});
</script>
    
</head>

<body>

<table width="100%">
  <tr>   
    <td width="8%" height="114">
      <center> 
     <img src="../img/logo.png" width="70" height="52"  alt=""/>    
    </center>
    </td>
    <td width="72%" style="font-size: 36px; font-style: normal; font-weight: bold;"> Sistema Financeiro</td>
    <td width="8%">
    <center> 
    <img style="text-align:center;"src="../img/happy.png" width="61" height="44"  alt=""/>
    </center>
    </td>
    <td width="12%">
     <center>
    <p>Bem Vindo,</p>
    <p>
	<?php echo $usuario = str_replace("<BR />","",strtoupper(Util::get_usuario_logado())); ?><br>
    <a href="../view/v_login.php">Log OFF</a>
	</p>    
    </td>    
  </tr>
</table>
<?php $_POST['i_usuario2'] = $usuario; ?>
    
<hr>
<div style="clear:both;height:20px;">

<div style="float:left;"><a href="v_inicio.php">Inicio</a>&gt; Movimentações </div>



<div style="float:right;">Seu Saldo Atual: {<?php $movimentacao->get_saldo_formatado($usuario); ?>}
</div>
</div>
<hr>


<?php 
    if($util->campo_valido($_POST['flag'])){
        $flag = $_POST['flag'];
        
        if($flag==="editar"){
            $id_movimentacao=$_POST['id_movimentacao'];
            
            #var_dump($dados = $sql->select("*","t_usuario","where id_usuario=$id_usuario"));
            $dados = $sql->select("*","t_movimentacao","where id_movimentacao=$id_movimentacao");
            
            #var_dump($dados);
            
            $v_data_movimento=$dados['dados'][0]['data_movimento'];;
            $v_tipo=$dados['dados'][0]['tipo']; 
            $v_descricao=$dados['dados'][0]['descricao']; 
            $v_valor=$dados['dados'][0]['valor']; 
            $v_categoria_id=$dados['dados'][0]['categoria_id']; 
            
            $id_ = $sql->select("*","t_categoria","where id_categoria = $v_categoria_id");
            #var_dump($id_);
            $v_nome_categoria=$id_['dados'][0]['nome']; 
            
            #var_dump($v_nome_categoria);
            
            $flag="editar";
            $v_botao="SALVAR"; 
            
#corrigir esse bloco
            $v_caminho="../controller/c_atualizar_movimento.php";
        }else{
            $id_movimentacao="";
            $v_data_movimento="";
            $v_tipo=""; 
            $v_descricao=""; 
            $v_valor="";
            $v_nome_categoria_="";
            $v_categoria_id="";
            
            $v_botao="Adicionar_Movimentação"; 
            
            $v_caminho="../controller/c_movimentacao.php";
        }   
     
    }else{
        echo "flag nao submetida";
    }

?>


<div align="center" id="conteudo"></div>
<!--
<div id="filtro">
<form action="../controller/c_filtro.php" method="post" name="form_mov2" id="form_mov2">
<fieldset>
<legend>Filtro</legend>
  <table width="400">
    <tr>
      <td>
          <label>
            <input type="checkbox" name="tipo_r" value="CREDITO" id="tipo_r">
            Receitas
            </label>     
       </td> 
      <td>
                <label>
            <input type="checkbox" name="tipo_d" value="DEBITO" id="tipo_d">
            Despesas</label>      
      </td>
    </tr>
    <tr>
        <td>Mes/Ano: </td>
        <td><input name="mes_ano" type="month">
        <img src="../img/agenda.png" width="24" height="24"  alt=""/></td>
    </tr>
    <tr>
    <td></td>
    <td><input id="btn_filtrar" type="submit" value="Filtrar"></td>
    </tr>
  </table>
  </fieldset>
</form>
</div>
<br>
-->

<div style="width:500px">
<form action=<?php echo $v_caminho; ?> method="post" name="form_mov" id="form_mov">
<fieldset>

<legend>Nova Movimentação</legend>
 <table width="500">
  <tr>
    <th style="text-align: left" scope="row">Tipo:</th>
    <TD>
    <?php 
	if($flag!=='editar'){
	    echo "
	    <select id='tipo' name='tipo' size='1' required>
	    <option name='vazio' value=''>Escolha um Tipo</option>
	    <option name='debito' value='DEBITO'>DEBITO</option>
	    <option name='credito' value='CREDITO'>CREDITO</option>
	    </select>";
	}else{
	    if($v_tipo==="DEBITO"){
		 echo "
	     <select id='tipo' name='tipo' size='1' required>
	     <option name='vazio' value=''>Escolha um Tipo</option>
	    <option name='debito' value='DEBITO' selected>DEBITO</option>
	    <option name='credito' value='CREDITO'>CREDITO</option>
	    </select>";
	    }else{
		 echo "
	    <select id='tipo' name='tipo' size='1' required>
	    <option name='vazio' value=''>Escolha um Tipo</option>
	    <option name='debito' value='DEBITO'>DEBITO</option>
	    <option name='credito' value='CREDITO' selected>CREDITO</option>
	    </select>";
	    }
	}

    
    ?>
    
    </TD>
    <td>
	<input type="hidden" name="i_usuario" id="i_usuario" value="">
        <input type="hidden" name="id_movimentacao" id="id_categoria" value=<?php echo $id_movimentacao; ?>>
        
       </td>
  </tr>
  <tr>
    <th style="text-align: left" scope="row">Data:</th>
    <td><input id="data" type="date" name="data" value='<?php echo $v_data_movimento; ?>' required>
      <img src="../img/agenda.png" width="24" height="24"  alt=""/></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th style="text-align: left" scope="row">Descrição:</th>
    <td><input name="descricao" id="descricao" type="text" value='<?php echo $v_descricao; ?>' required></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th style="text-align: left" scope="row">Valor:</th>
    <td><input id="valor" type="text" name="valor" value='<?php echo $v_valor; ?>' required></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th style="text-align: left" scope="row">Categoria:</th>
      

    
    <td><select id="categoria" name="categoria" required>
	    <option name='vazio' value=''>Escolha uma Categoria</option>
	     <?php $categoria->get_lista_Categoria(null); ?>
    </select></td>
    

    
    
    
    

    
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th style="text-align: left" scope="row">&nbsp;</th>
    <td></td>
    <td>
    <div style="float:right;height:60px; width:170px; clear:both;">
<input id ="new_mov" type="submit" value=<?php echo $v_botao; ?>>
</div></td>
  </tr>
</table>

</fieldset>
</form>
</div>
<br>

   <?php 
    if($flag==='editar'){
        
        
    
     echo "<script type='text/javascript'>
         document.getElementsByName('$v_categoria_id')[0].setAttribute('selected', 'selected');
          </script>";
     #echo '<script type="text/javascript">alert("hello!");</script>';
     
    }
    ?>


   <br>
<hr>
<br>
    
<fieldset>
    <legend><font color="blue">CRÉBITO</FONT></legend>    
<table width="900" cellspacing="2" cellpadding="2" border="1">
  <tr bgcolor='yellow'>
    <th scope="col">Data</th>
    <th scope="col">Tipo</th>
    <th scope="col">Descrição</th>
    <th scope="col">Valor</th>
    <th scope="col">Categoria</th>
    <!-- <th scope="col">Usuário</th> -->
    <!-- <th scope="col">Data Atualização</th> -->
    <th scope="col">Ação</th>
  </tr>
    <?php $movimentacao->get_tabela($usuario,'CREDITO',null);?>
    <?php $movimentacao->get_total($usuario,'CREDITO');?>
</table>
</fieldset>
<br>
<hr>
<br>
<fieldset>
    <legend><font color="red">DÉBITO</font></legend>
<table width="900" cellspacing="2" cellpadding="2" border="1">
  <tr bgcolor='yellow'>
    <th scope="col">Data</th>
    <th scope="col">Tipo</th>
    <th scope="col">Descrição</th>
    <th scope="col">Valor</th>
    <th scope="col">Categoria</th>
    <!--<th scope="col">Usuário</th> -->
    <!--<th scope="col">Data Atualização</th> -->
    <th scope="col">Ação</th>
  </tr>
    <?php $movimentacao->get_tabela($usuario,"DEBITO",null);?>
     <?php $movimentacao->get_total($usuario,'DEBITO');?>
</table>
</fieldset>

<script>
	$(document).ready( function() {
	    var x = <?php echo str_replace("<BR />","",strtoupper(Util::get_usuario_logado())) ?>;
	    //alert(x);
	    $("#i_usuario").val(x);	
	    
    });
</script>
    
    
    
    
</body>
</html>
