<?php include_once('../model/m_util.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>
<title>Pagina Recuperar</title>
</head>

<body>

<div align="center"><img src="../img/logo.png" width="153" height="69"  alt=""/>
</div>

<p align="center">Sistema Financeiro</p>
<p align="center">Gerenciador Pessoal de Finanças</p>
<div class="conteudo" border="1">
<p align="center">Recuperar Senha</p>
<hr>
<p align="center">Informe seu E-mail e Usuario para recuperar a senha</p>
  <form id="form1" action="../controller/c_recuperar_senha.php" name="form1" method="post">
    <p align="center">
	<label>Email: </label><br>
	<input name="email" type="text" id="email" placeholder="E-mail" 
	       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required><br>
	<label>Usuario: </label><br>
	<input name="usuario" type="text" id="usuario" placeholder="Usuario" pattern="[a-z0-9]+$" required>
    </p>
    <p align="center">
      <input type="submit" name="Acessar" id="Acessar" value="RECUPERAR">
    </p>
    <hr>
  </form>
  
  <div class="rodape"> 
    <div align="center">
   	<a href="../view/v_login.php">Retornar ao Login</a>     
     </div>
  </div>
  
</div>


    <script>
	$(document).ready( function() {

	    
	    $("#usuario").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
	
	    
	    $("#email").blur(function(){
		var x = $(this).val();
		var RegExp_ = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite o Email somente em letras minusculas\n e no formato valido\n exemplo@seila.com");
		    $(this).focus();
		}
	    });


    });
</script>
</body>
</html>
