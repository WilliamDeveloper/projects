<?php 
include_once('../model/m_util.php'); 
include_once('phpHtmlChart.php');
include_once("../model/m_conexao.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/script_jq.js"></script>
<title>Pagina Grafico</title>
</head>

<body>


<table width="100%">
  <tr>   
    <td width="8%" height="114">
      <center> 
     <img src="../img/logo.png" width="70" height="52"  alt=""/>    
    </center>
    </td>
    <td width="72%" style="font-size: 36px; font-style: normal; font-weight: bold;"> Sistema Financeiro</td>
    <td width="8%">
    <center> 
    <img style="text-align:center;"src="../img/happy.png" width="61" height="44"  alt=""/>
    </center>
    </td>
    <td width="12%">
     <center>
    <p>Bem Vindo,</p>
    <p>
	<?php echo $usuario = strtoupper(stripslashes(Util::get_usuario_logado())); ?><br>
    <a href="../view/v_login.php">Log OFF</a>
	</p>    
    </td>    
  </tr>
</table>



<hr>
<div style="clear:both;height:20px;">

<div style="float:left;"><a href="v_inicio.php">Inicio</a>&gt; Gráfico </div>



<div style="float:right;">Seu Saldo Atual: {<?php $movimentacao->get_saldo_formatado($usuario); ?>}
</div>
</div>
<hr>

<div align="center" id="conteudo">
 <?php 

        
        $usu = str_replace("<BR />","",strtoupper(Util::get_usuario_logado()));
        #$usu = str_replace("'","",$usu);
        #var_dump($usu);
        
        $dadosTotal = $sql->select("count(*) total","t_movimentacao","where usu_atu = $usu");
        $dadosDebito = $sql->select("count(*) debito","t_movimentacao","where usu_atu = $usu and tipo = 'DEBITO'");
        $dadosCredito = $sql->select("count(*) credito","t_movimentacao","where usu_atu = $usu and tipo = 'CREDITO'");
        
echo "<meta charset='utf-8'>";

echo "<br><br>";
	$aGraphData = Array
		(array('DEBITO', $dadosDebito['dados'][0]['debito'], ''),
		 array('CREDITO', $dadosCredito['dados'][0]['credito'], ''),
		
		);
                
	echo phpHtmlChart($aGraphData, 'H', 'Quantidade de Movimentação por Tipo', 
		'Quantidade de Movimentos', '12pt', 500, 'px', 35, 'px');
	
		if($dadosDebito['dados'][0]['debito']== 0 ){
		  $porcentagem_debito = 0;
		}else{
		    $porcentagem_debito = (($dadosDebito['dados'][0]['debito']/$dadosTotal['dados'][0]['total'])*100);
		}
		
		if($dadosCredito['dados'][0]['credito'] == 0){
		  $porcentagem_credito = 0;  
		}else{
		    $porcentagem_credito = (($dadosCredito['dados'][0]['credito']/$dadosTotal['dados'][0]['total'])*100);
		}

                echo "<br><hr><br>";
        	$aGraphData2 = Array
		(array('DEBITO', $porcentagem_debito, '%'),
		 array('CREDITO', $porcentagem_credito, '%'),
		
		);
        echo phpHtmlChart($aGraphData2, 'H', 'Porcentagem sobre o Total de quantidade Movimentação por Tipo',
		'Porcentagem do Tipo Movimentação', '12pt', 500, 'px', 35, 'px');
        
        #---------------------------------------------------------------------------------------------------
 #       $movimentacao = $sql->select("c.nome categoria,count(*) total","t_movimentacao m,t_categoria c","where m.categoria_id = c.id_categoria and m.usu_atu = $usu group by c.nome");
  
#$movimentacao = $sql->select("c.nome categoria,count(*) total","t_categoria c","where id_categoria in(select categoria_id from t_movimentacao where usu_atu = $usu) group by c.nome");

echo "<br><br><br>";
###############################################################################               
echo "<br><hr><br>";
	     $result_movimentacao = $sql->select("c.nome categoria,count(m.categoria_id) total",
"t_categoria c left outer join t_movimentacao m on c.id_categoria = m.categoria_id and m.usu_atu = $usu" ,
		     "group by c.nome");

        for($i=0;$i<$result_movimentacao['num'];$i++){
            $chave = $result_movimentacao['dados'][$i]['categoria'];
            $valor = $result_movimentacao['dados'][$i]['total'];
            $outro = '';            
            $dGraf[$i]= array($chave,$valor,$outro);
        }
        
      echo phpHtmlChart($dGraf, 'H', 'Quantidade de Movimentação Cadastradas por Categoria', 
	      'Quantidade de Movimentação', '12pt', 500, 'px', 35, 'px');
        
         ########################################################################    
       echo "<br><hr><br>"; 
        
        #$v_total_saldo = $movimentacao->get_saldo_atual($usu);
	$v_total_credito = $movimentacao->get_saldo_credito($usu);
	$v_total_debito = $movimentacao->get_saldo_debito($usu);
        $v_total_saldo = $v_total_credito + $v_total_debito;	
	
		if($v_total_debito== 0 ){
		  $perc_debito = 0;
		}else{
		   $perc_debito = (($v_total_debito/$v_total_credito)*100);
		}
		
		if($v_total_credito == 0){
		  $perc_credito = 0;  
		}else{
		    $perc_credito = (($v_total_credito/$v_total_credito)*100);
		}
	
        $aGraphData = Array
		(array('DEBITO', $perc_debito, '%'),
		 array('CREDITO', $perc_credito, '%'),
		
		);
                #var_dump($aGraphData);
	echo phpHtmlChart($aGraphData, 'H', 
		'Porcentagem das Receitas e Despesas', 
		'Porcentagem representativa dos tipo de movimentação', '12pt', 600, 'px', 35, 'px');
	
	echo "<br><hr><br>";
	
	
	$result_movimentacao = $sql->select("c.nome categoria,sum(m.valor) total",
"t_categoria c left outer join t_movimentacao m on c.id_categoria = m.categoria_id and m.usu_atu = $usu" ,
		     "group by c.nome");

       ######################################################################## 
        echo "<br><br><br>";

        for($i=0;$i<$result_movimentacao['num'];$i++){
            $chave = $result_movimentacao['dados'][$i]['categoria'];
            $valor = sprintf("%01.2f",$result_movimentacao['dados'][$i]['total']);
            $outro = '';            
            $dGraf[$i]= array($chave,$valor,$outro);
            
        }
        
      echo phpHtmlChart($dGraf, 'H', 'Total Gasto em cada Categoria de Movimentação',
	      'Valor das Movimentações', '12pt', 600, 'px', 35, 'px');
	
        
?>
</div>



</body>
</html>
