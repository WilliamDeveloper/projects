<?php include('../model/m_util.php'); ?>
<?php include_once('../model/m_conexao.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/script_jq.js"></script>
<title>Pagina inicio</title>
</head>

<body id="geral">

<table width="100%">
  <tr>   
    <td width="8%" height="114">
      <center> 
     <img src="../img/logo.png" width="70" height="52"  alt=""/>    
    </center>
    </td>
    <td width="72%" style="font-size: 36px; font-style: normal; font-weight: bold;"> Sistema Financeiro</td>
    <td width="8%">
    <center> 
    <img style="text-align:center;"src="../img/happy.png" width="61" height="44"  alt=""/>
    </center>
    </td>
    <td width="12%">
     <center>
    <p>Bem Vindo,</p>
    <p>
	<?php echo $usuario = str_replace("<BR />","",strtoupper(Util::get_usuario_logado())); ?><br>
    <a href="../view/v_login.php">Log OFF</a>
	</p>    
    </td>    
  </tr>
</table>




<hr style="clear:both">
<p>Seu Saldo Atual: {<?php $movimentacao->get_saldo_formatado($usuario); ?>} </p>
<hr>
<div align="center" id="conteudo">
  
  
  <table width="400">
      <!--
  <tr>
    <td width="167">&nbsp;</td>
    <td width="217"><a id="agenda" href="#">
<input name="agenda" type="image" src="../img/agenda.png" alt="Agenda">
<label>Agenda</label>
</a></td>
    
  </tr>
  -->
  <tr>
    <td>&nbsp;</td>
    <td>
              <form id="theForm" action="../view/v_movimentacao.php" name="theForm" method="post">
                <input type="hidden" name="flag" value="normal">
        
                  <a id="movimentacao" href="javascript:document.theForm.submit();">        
                    <input name="Movimentacoes" type="image" src="../img/movimentacao.png" alt="Movimentacoes">
                    <label>Movimentações</label>               
                </a> 
              </form>
    </td>    
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><a id="grafico" href="#">
<input name="Gráficos" type="image" src="../img/grafico.png" alt="Agenda">
<label>Gráficos</label>
</a></td>
    
  </tr>
  <!--
  <tr>
    <td>&nbsp;</td>
    <td><a id="orcamento" href="#">
<input name="Orcamento" type="image" src="../img/orcamento.png" alt="Orçamento">
<label>Orçamento</label>
</a></td>
  </tr>
  -->
  
  <?php 
  #$usuario = str_replace ('\'', '',$usuario);
   $usuario = str_replace ('\'', '',$usuario);

    if($usuario ==='ADMIN'){
	echo "  
      <tr>
      <td>&nbsp;</td>
      <td>
      <form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>
        
        <a id='usuario' href='javascript:document.theForm.submit();'>        
            <input name='usuario' type='image' src='../img/usuario.png' alt='Usuarios'>
            <label>Administrar Usuários</label>        
            
        </a>       
      
    </form>
        
      </td>      
      </tr> ";
    }else{
	#echo "errado";
    }
  
    

  ?>
  
  
</table>

  
  

  
</div>



</body>
</html>
