<?php include_once('../model/m_util.php'); ?>
<?php include_once('../model/m_conexao.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/script_jq.js"></script>


<title>Administracao Usuarios</title>
</head>

<body>

<table width="100%">
  <tr>   
    <td width="8%" height="114">
      <center> 
     <img src="../img/logo.png" width="70" height="52"  alt=""/>    
    </center>
    </td>
    <td width="72%" style="font-size: 36px; font-style: normal; font-weight: bold;"> Sistema Financeiro</td>
    <td width="8%">
    <center> 
    <img style="text-align:center;"src="../img/happy.png" width="61" height="44"  alt=""/>
    </center>
    </td>
    <td width="12%">
     <center>
    <p>Bem Vindo,</p>
    <p>
	<?php echo $usuario = str_replace("<BR />","",strtoupper(Util::get_usuario_logado())); ?><br>
    <a href="../view/v_login.php">Log OFF</a>
	</p>    
    </td>    
  </tr>
</table>
<?php $_POST['i_usuario2'] = $usuario; ?>
    
<hr>
<div style="clear:both;height:20px;">

<div style="float:left;"><a href="v_inicio.php">Inicio</a>&gt; Administração de Usuários </div>



<div style="float:right;">Seu Saldo Atual: {<?php $movimentacao->get_saldo_formatado($usuario); ?>}
</div>
</div>
<hr>

<div align="center" id="conteudo"></div>


<br>

<?php 
    if($util->campo_valido($_POST['flag'])){
        $flag = $_POST['flag'];
        
        if($flag==="editar"){
            $id_usuario=$_POST['id_usuario'];
            
            #var_dump($dados = $sql->select("*","t_usuario","where id_usuario=$id_usuario"));
            $dados = $sql->select("*","t_usuario","where id_usuario=$id_usuario");
            
            $v_email=$dados['dados'][0]['email'];;
            $v_usuario=$dados['dados'][0]['usuario']; 
            $v_senha=$dados['dados'][0]['senha']; 
            
            $v_botao="SALVAR"; 
            

            $v_caminho="../controller/c_atualizar_usuario.php";
        }else{
            $id_usuario="";
            $v_email="";
            $v_usuario=""; 
            $v_senha=""; 
            $v_botao="CADASTRAR";
            $v_caminho="../controller/c_registrar.php";
        }   
     
    }else{
        echo "flag nao submetida";
    }

?>

<fieldset>
    <legend><font color="blue">Adicionar Usuário</FONT></legend> 
<div style="width:500px">
  <form id="form1" action=<?php echo $v_caminho; ?> name="form1" method="post">
  <p align="center">  
  <label>Email: </label><br>
  <input name="email" type="text" id="email" placeholder="exemplo@seila.com" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value='<?php echo $v_email; ?>' required>
  </p>
  <p align="center">
  <label>Usuário: </label><br>
  <input name="usuario" type="text" id="usuario" placeholder="letras a-z e numero 0-9" pattern="[a-z0-9]+$" value='<?php echo $v_usuario; ?>' required>
  </p>
  <p align="center">  
      <label>Senha: </label><br>
      <input name="senha" type="password" id="senha" placeholder="letras a-z e numero 0-9" pattern="[a-z0-9]+$" value='<?php echo $v_senha; ?>' required>
  </p>
  <p align="center">  
      <label>Confirmação de Senha: </label><br>
      <input name="confirm" type="password" id="confirm" placeholder="letras a-z e numero 0-9" pattern="[a-z0-9]+$" value='<?php echo $v_senha; ?>' required>
  <input name="reg_admin" type="hidden" id="reg_admin" placeholder="reg_admin" value="reg_admin">
  <input type='hidden' name='id_usuario' value=<?php echo $id_usuario; ?>>
  </p>
  
  <p align="center">
  <input type="reset" name="Acessar" id="Acessar" value="Limpar">
  &nbsp;&nbsp;&nbsp;&nbsp;
  <input type="submit" name="Acessar" id="Acessar" value=<?php echo $v_botao; ?>>
  </p>
  </form>
</div>
</fieldset>    
    
<br>

<table width="900" cellspacing="2" cellpadding="2" border="1">
  <tr bgcolor='yellow'>
    <th scope="col">Usuário</th>
    <th scope="col">Email</th>
    <th scope="col">Senha</th>
    <th scope="col">Usuario criador</th>
    <th scope="col">Data Atualização</th>
    <th scope="col">Ação</th>
  </tr>
    <?php $usuarios->get_tabela();?>
</table>


<script>
	$(document).ready( function() {
	    var x = <?php echo str_replace("<BR />","",strtoupper(Util::get_usuario_logado())) ?>;
	    //alert(x);
	    $("#i_usuario").val(x);
	    
	    $("#usuario").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
		    
	    $("#senha").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
	    
	    $("#confirm").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
	    
	    $("#email").blur(function(){
		var x = $(this).val();
		var RegExp_ = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite o Email somente em letras minusculas\n e no formato valido\n exemplo@seila.com");
		    $(this).focus();
		}
	    });


    });
</script>
    
    
    
    
</body>
</html>
