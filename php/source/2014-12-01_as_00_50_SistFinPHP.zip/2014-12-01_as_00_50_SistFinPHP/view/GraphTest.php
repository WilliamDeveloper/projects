<?php include('../model/m_util.php'); ?>

<?php
	include('phpHtmlChart.php');
        include_once("../model/m_conexao.php");
        
        $usu = str_replace("<BR />","",strtoupper(Util::get_usuario_logado()));
        #$usu = str_replace("'","",$usu);
        #var_dump($usu);
        
        $dadosTotal = $sql->select("count(*) total","t_movimentacao","where usu_atu = $usu");
        $dadosDebito = $sql->select("count(*) debito","t_movimentacao","where usu_atu = $usu and tipo = 'DEBITO'");
        $dadosCredito = $sql->select("count(*) credito","t_movimentacao","where usu_atu = $usu and tipo = 'CREDITO'");
    #    var_dump($dadosTotal);
     #   var_dump($dadosCredito);
     #   var_dump($dadosDebito);

        
echo "<meta charset='utf-8'>";

                  echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";

echo "<br><br>";
	$aGraphData = Array
		(array('DEBITO', $dadosDebito['dados'][0]['debito'], ''),
		 array('CREDITO', $dadosCredito['dados'][0]['credito'], ''),
		
		);
                #var_dump($aGraphData);
	echo phpHtmlChart($aGraphData, 'H', 'Quantidade de Movimentação por Tipo', 'Quantidade de Movimentos', '8pt', 400, 'px', 15, 'px');
        
                $porcentagem_debito = (($dadosDebito['dados'][0]['debito']/$dadosTotal['dados'][0]['total'])*100);
                $porcentagem_credito = (($dadosCredito['dados'][0]['credito']/$dadosTotal['dados'][0]['total'])*100);
                #var_dump($porcentagem_debito);
                #var_dump($porcentagem_credito);
                echo "<br><hr><br>";
        	$aGraphData2 = Array
		(array('DEBITO', $porcentagem_debito, '%'),
		 array('CREDITO', $porcentagem_credito, '%'),
		
		);
        echo phpHtmlChart($aGraphData2, 'H', 'Porcentagem de Movimentação por Tipo', 'Porcentagem do Tipo Movimentação', '8pt', 400, 'px', 15, 'px');
?>