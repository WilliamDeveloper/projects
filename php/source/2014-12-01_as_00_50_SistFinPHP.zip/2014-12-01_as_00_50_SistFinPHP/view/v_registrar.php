<?php include_once('../model/m_util.php'); ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="../js/jquery-1.11.1.min.js"></script>

<title>Pagina Registrar</title>
</head>

<body>

<div align="center"><img src="../img/logo.png" width="153" height="69"  alt=""/>
</div>


<div class="conteudo" border="1">
  <p align="center">Registro de Novo Usuario</p>
  <hr>
  <p align="center">Informe seus dados para iniciar</p>
  <form id="form1" action="../controller/c_registrar.php" name="form1" method="post">
  <p align="center">
   <label>Email: </label><br>
  <input name="email" type="text" id="email" placeholder="exemplo@seila.com" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
  </p>
  <p align="center">
  <label>Usuario: </label><br>
  <input name="usuario" type="text" id="usuario" placeholder="Usuário" pattern="[a-z0-9]+$" required>
  </p>
  <p align="center">  
   <label>Senha: </label><br>
  <input name="senha" type="password" id="senha" placeholder="Senha" pattern="[a-z0-9]+$" required>
  </p>
  <p align="center">  
   <label>Confirmação de Senha: </label><br>
  <input name="confirm" type="password" id="confirm" placeholder="Confirmação de Senha" pattern="[a-z0-9]+$" required>
  <input name="reg_admin" type="hidden" id="reg_admin" placeholder="reg_admin" value="cadastro">
  
  </p>
  
  <p align="center">
  <input type="reset" name="Acessar" id="Acessar" value="Limpar">
  &nbsp;&nbsp;&nbsp;&nbsp;
  <input type="submit" name="Acessar" id="Acessar" value="CADASTRAR">
  </p>
  <hr>
  </form>
  
  <div class="rodape"> 
  <div align="center">
  <a href="v_login.php">Retornar ao Login</a>     
  </div>
  </div>
  
</div>

    
    
    <script>
	$(document).ready( function() {

	    
	    $("#usuario").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
		    
	    $("#senha").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
	    
	    $("#confirm").blur(function(){
		var x = $(this).val();
		var RegExp_ = /^[a-z0-9]+$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite somente letras minusculas de a-z e numeros 0-9");
		    $(this).focus();
		}
	    });
	    
	    $("#email").blur(function(){
		var x = $(this).val();
		var RegExp_ = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
		if(RegExp_.test(x)==false){
		    alert("Campo invalido!\n\nDigite o Email somente em letras minusculas\n e no formato valido\n exemplo@seila.com");
		    $(this).focus();
		}
	    });


    });
</script>
</body>
</html>
