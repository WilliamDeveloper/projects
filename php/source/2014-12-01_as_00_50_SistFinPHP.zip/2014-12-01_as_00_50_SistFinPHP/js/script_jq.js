$(document).ready( function() {
    $("#agenda").on("click", function() {
        $("#geral").load("../view/v_agenda.php");
    });
 //   $("#movimentacao").on("click", function() {
  //      $("#geral").load("../view/v_movimentacao.php");
   // });
	$("#grafico").on("click", function() {
        $("#geral").load("../view/v_grafico.php");
    });
	$("#orcamento").on("click", function() {
        $("#geral").load("../view/v_orcamento.php");
    });
   // 	$("#usuario").on("click", function() {
   //     $("#geral").load("../view/v_usuario.php");
   // });
//    $("#new_mov").on("click", function() {
//	var tipo = $("#tipo").val();
//	var data = $("#data").val();
//	var descricao = $("#descricao").val();
//	var valor = $("#valor").val();
//	var categoria = $("#valor").val();
//	var usuario = $("#i_usuario").val();
//	
//	
//	
//        $("#geral").load("../view/v_movimentacao.php");
//	
//    });
});