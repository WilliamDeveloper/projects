<?php
  require_once 'm_config.php';
  include_once('m_crud.php');
  include_once('m_util.php');
  include_once('m_movimentacao.php');
  include_once('m_categoria.php');
  include_once('m_usuarios.php');
  $sql = new Dados;
  $util = new Util;
  $movimentacao = new Movimentacao;
  $categoria = new Categoria;
  $usuarios = new Usuarios;

