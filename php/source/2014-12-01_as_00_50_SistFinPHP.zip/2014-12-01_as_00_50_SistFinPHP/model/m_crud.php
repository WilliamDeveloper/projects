<?php
class Dados{
	/*********C_R_U_D--->C*********************************/
   #$create = Dados::create('usuarios', $f);
   #$create = $sql->create('usuarios', $f);
   #if($create!==true){}
    public static function create($tabela, array $dados){
		global $conn;	
		$campos = implode(',',array_keys($dados));
		$valores= "'".implode("','",array_values($dados))."'";	
		$sql = "INSERT INTO {$tabela} ($campos) values ($valores)";
		#var_dump($sql);//vendo o que tem na query
		$query = $conn->query($sql);	
		if($query){
			return true;
		}	
		return $sql;
    }
	
	/*********C_R_U_D--->R*********************************/
    #$read = $sql->select("*","t_usuario","where usuario = 'william'");
    #$read = $sql->select("usuario,email","t_usuario",null);
    #var_dump($sql->select("*","t_usuario","order by usuario desc"));
    #var_dump($read);    
    public static function select($campos ,$tabela, $condicao){	
		global $conn;
		$condicao = ($condicao!==null) ? " {$condicao}" : null;
		$sql = "SELECT {$campos} FROM {$tabela}{$condicao}";
		#var_dump($sql);//vendo o que tem na query
		$query = $conn->query($sql);
		$dados= array();
		while($rs =  mysqli_fetch_array($query)){
		 $dados[] = $rs;
		}
		$d['num'] = mysqli_num_rows($query);
		$d['dados'] = $dados;
		return $d;	
    }
	
	/*********C_R_U_D--->U*********************************/
    #$f['usuario']='carlos';
   #$update = $sql->update('t_usuario',$f,"id=95");
    #IF($UPDATE!== TRUE){}
    public static function update($tabela,array $dados, $cond){
		#update tabela set campo = valor where cond;
		global $conn;
		foreach($dados as $campo => $valor){
			$rs[] = "{$campo}='{$valor}'";
		}
		$campos = implode(',',$rs);
		$sql = "UPDATE {$tabela} SET {$campos} WHERE {$cond}";// NAO TINHA CHAVES
		#var_dump($sql);//vendo o que tem na query
		$query = $conn->query($sql);
		if($query){
			return true;
		}
		return $sql;
    }
	
	/*********C_R_U_D--->D*********************************/
    #$deletar = $sql->delete('usuarios','id=96');
    #IF($DELETAR!== TRUE){}
    public static function delete($tabela, $cond){
		global $conn;
		$sql = "DELETE FROM {$tabela} WHERE {$cond}";
		#var_dump($sql);//vendo o que tem na query
		$query = $conn->query($sql);
		
		if($query){
			return true;
		}
		return $sql;	
    }
}

//pode ser usar null nos parametros