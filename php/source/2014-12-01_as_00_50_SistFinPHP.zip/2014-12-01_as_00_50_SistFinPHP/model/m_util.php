<?php

class Util{
    
    public static function campo_valido($campo){
	if(isset($campo) && !empty($campo)){
	    return true;
	} return false;
    }
    
    public static function get_usuario_logado(){
    	$file = fopen("../model/Dados.txt","r") or die("problemas ao ler arquivo");    
	//enquanto nao esta no final do arquivo
	while(!feof($file)){
	    $obter = fgets($file);
	    #$linha = nl2br($obter);
	    #return $linha;
	    break;
	}
	return stripcslashes(str_replace("\r\n","",$obter));
	#return stripcslashes($linha);
	fclose($file);
    }
    
        public static function get_id_usuario_logado(){
    	$file = fopen("../model/id_Dados.txt","r") or die("problemas ao ler arquivo");    
	//enquanto nao esta no final do arquivo
	while(!feof($file)){
	    $obter = fgets($file);
	    #$linha = nl2br($obter);
	    #return $linha;
	    break;
	}
	return stripcslashes(str_replace("\r\n","",$obter));
	#return stripcslashes($linha);
	fclose($file);
    }
}
