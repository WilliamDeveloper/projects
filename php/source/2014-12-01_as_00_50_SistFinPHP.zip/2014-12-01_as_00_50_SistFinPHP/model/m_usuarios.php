<?php


class Usuarios {
    
     public static $dados;
    
    
    function __construct() {
	$this->dados = Dados::select("*","t_usuario",null);
    }
    
    
    function get_usuario($i){
	
	return $this->dados['dados'][$i]['usuario'];
    }
    function get_id_usuario($i){
	#$this->dados = Dados::select("nome","t_categoria",null);
	return $this->dados['dados'][$i]['id_usuario'];
    }
    
    function get_size(){
	
	return $this->dados['num'];
    }
    
    function get_email($i){
	
	return $this->dados['dados'][$i]['email'];
    }

    
    function get_senha($i){
	
	return $this->dados['dados'][$i]['senha'];
    }

   
    function get_usu_atu($i){
	
	return $this->dados['dados'][$i]['usu_atu'];
    }
    function get_dh_atu($i){
	
	return $this->dados['dados'][$i]['dh_atu'];
    }

    
    
    function get_tabela(){
	#$this->set_usuario($usuario);
	#echo "<br><hr><br>";
	if($this->get_size()===0){
	    echo "<tr >";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	  
	    echo "</tr>";
	}else{
	    for ($i = 0 ;$i< $this->get_size();$i++){
		
		#var_dump($this->get_id_movimentacao($i))	;
		echo "<tr >";
		echo "<td class='linha_movimento'>".$this->get_usuario($i)."</td>";
		echo "<td class='linha_movimento'>".$this->get_email($i)."</td>";
		echo "<td class='linha_movimento'>".$this->get_senha($i)."</td>";
		echo "<td class='linha_movimento'>".$this->get_usu_atu($i)."</td>";
		echo "<td class='linha_movimento'>".$this->get_dh_atu($i)."</td>";
		echo "<td>"
                        . "<form action='../controller/c_deletar_usuario.php' method='post'>"
                        . "<input type='hidden' name='excluir' value=".$this->get_id_usuario($i).">"
                        . "<input type='hidden' name='flag' value='excluir'>"
                        . "<input type='submit' value='EXCLUIR'>"
                        . "</form>"
                        
                        . "<form action='../view/v_usuario.php' method='post'>"
                        . "<input type='hidden' name='id_usuario' value=".$this->get_id_usuario($i).">"
                        . "<input type='hidden' name='flag' value='editar'>"
                        . "<input type='submit' value='EDITAR'>"
                        . "</form>"
                    . "</td>";
                
		echo "</tr>";
	    }
	}
    }
}