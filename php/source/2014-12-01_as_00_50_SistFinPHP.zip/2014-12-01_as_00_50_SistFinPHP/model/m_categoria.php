<?php


class Categoria {
    
     public static $dados;
    
    
    function __construct() {
	$this->dados = Dados::select("id_categoria,nome,tipo","t_categoria",null);
    }
    
    
    function get_nome($i){
	
	return $this->dados['dados'][$i]['nome'];
    }
    function get_id_categoria($i){
	#$this->dados = Dados::select("nome","t_categoria",null);
	return $this->dados['dados'][$i]['id_categoria'];
    }
    
    function get_size(){
	
	return $this->dados['num'];
    }
    
        function get_tipo($i){
	
	return $this->dados['dados'][$i]['tipo'];
    }
   
    
    function get_lista_categoria($tipo){
	for ($i = 0 ;$i< $this->get_size();$i++){
	    $opt = $this->get_nome($i);
            $tmp_tipo = $this->get_tipo($i);
            if($tipo === $tmp_tipo){
                $id_categoria = $this->get_id_categoria($i);
                 echo "<option data-tipo='$tmp_tipo' name='$id_categoria' value='$id_categoria'>$opt</option>";
            }else{
                if($tipo === null){ 
                    $id_categoria = $this->get_id_categoria($i);
                    echo "<option data-tipo='$tmp_tipo' name='$id_categoria' value='$id_categoria'>$opt</option>";
                    echo "<script>document.getElementById('categoria').appendChild($id_categoria);</script>";
                }
            }
	}
    }
    
    
    
}