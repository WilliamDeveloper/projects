<?php
include_once('../model/m_util.php'); 
include_once('../model/m_conexao.php'); 


class Movimentacao{
    public static $dados;
	public static $saldo_debito;
	public static $saldo_credito;
    
    
    function __construct() {
	
    }
    
    function set_usuario($usuario , $tipo){
        #var_dump($tipo2);
        #$tipo = "CREDITO";
	$this->dados = Dados::select("id_movimentacao,data_movimento,a.tipo,descricao,valor,b.nome,a.usu_atu,a.dh_atu", "t_movimentacao a,t_categoria b", "where a.usu_atu = $usuario and a.categoria_id = b.id_categoria and a.tipo = '$tipo'");
	#var_dump($this->dados);
#var_dump($this->dados[dados][0][data_movimento]);
    }
    
    function get_size(){
	return $this->dados['num'];
    }
    
	function get_id_movimentacao($i){
	#var_dump($this->dados);
	return $this->dados['dados'][$i]['id_movimentacao'];
	#var_dump();
    }
    
    function get_data_movimento($i){
	//var_dump($this->dados);
	return $this->dados['dados'][$i]['data_movimento'];
    }
    
    function get_tipo($i){
	return $this->dados['dados'][$i]['tipo'];
    }
    
    function get_descricao($i){
	return $this->dados['dados'][$i]['descricao'];
    }
    
    function get_valor($i){
	return $this->dados['dados'][$i]['valor'];
    }
    
    function get_categoria_id($i){
	return $this->dados['dados'][$i]['nome'];
    }
    
    function get_usu_atu($i){
	return $this->dados['dados'][$i]['usu_atu'];
    }
    
    function get_dh_atu($i){
	return $this->dados['dados'][$i]['dh_atu'];
    }
	
	function get_saldo_debito(){
		return $this->saldo_debito['dados'][0]['valor'];
	}
	
	function get_saldo_credito(){
		return $this->saldo_credito['dados'][0]['valor'];
	}
	
	function get_saldo_atual($usuario){
	 #echo "sadas";
	 $this->saldo_debito = Dados::select("COALESCE(sum(valor), 0) valor", "t_movimentacao", "where tipo = 'DEBITO' and usu_atu = $usuario");
	 $this->saldo_credito = Dados::select("COALESCE(sum(valor), 0) valor", "t_movimentacao", "where tipo = 'CREDITO' and usu_atu = $usuario");
	 
	#var_dump($this->dados);
	
	#echo "<br>credito<br>";
	#var_dump($this->get_saldo_credito());
	#echo "<br>debito<br>";
	#var_dump($this->get_saldo_debito());
	#echo "<br>fim<br>";
	#var_dump($this->dados[dados][0][data_movimento]);
	 return ($this->get_saldo_credito()-$this->get_saldo_debito());
	}
	
	function get_saldo_formatado($usuario){
	    $saldo = $this->get_saldo_atual($usuario);
	    if($saldo >=0){
		$cor = "blue";
	    }else{
		$cor = "red";
	    }	    
		echo "<font color=".$cor.">R$ ".sprintf("%01.2f",$saldo)."</FONT>";
	}
    
    function get_total($usuario, $tipo){
	
	$this->get_saldo_atual($usuario);
	if($tipo =="CREDITO"){
	    $total = sprintf("%01.2f",$this->get_saldo_credito());
	}else if($tipo =="DEBITO"){
	    $total = sprintf("%01.2f",$this->get_saldo_debito());
	}else{
	    $total = "";
	}
	    echo "<tr bgcolor='yellow'>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>TOTAL</td>";
	    echo "<td>R$ $total</td>";
	    echo "<td>&nbsp;</td>";
	    #echo "<td>&nbsp;</td>";
	    #echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "</tr>";
    }
    
    function get_tabela($usuario,$tipo,$data){
	$this->set_usuario($usuario,$tipo);
	#echo "<br><hr><br>";
	if($this->get_size()===0){
	    echo "<tr>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    #echo "<td>&nbsp;</td>";
	    #echo "<td>&nbsp;</td>";
	    echo "<td>&nbsp;</td>";
	    echo "</tr>";
	}else{
	    for ($i = 0 ;$i< $this->get_size();$i++){
		
		if($this->get_tipo($i)==='DEBITO'){
		$cor = "red";
		}else if($this->get_tipo($i)==='CREDITO'){
		$cor = "blue";
		}else{
		$cor = "black";
		}
                #$var = round(1.95583, 2); // Retorna 1.96 
                #$formatted = sprintf("%01.2f", $money);
		#var_dump($this->get_id_movimentacao($i))	;
		echo "<tr>";
		echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_data_movimento($i)."</FONT></td>";
		echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_tipo($i)."</FONT></td>";
		echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_descricao($i)."</FONT></td>";
		echo "<td class='linha_movimento'><font color=".$cor."> R$ ".sprintf("%01.2f",$this->get_valor($i))."</FONT></td>";
		echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_categoria_id($i)."</FONT></td>";
		#echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_usu_atu($i)."</FONT></td>";
		#echo "<td class='linha_movimento'><font color=".$cor.">".$this->get_dh_atu($i)."</FONT></td>";
		echo "<td><center>"
                        . "<form action='../controller/c_deletar_movimento.php' method='post'>"
                        . "<input type='hidden' name='excluir' value=".$this->get_id_movimentacao($i).">"
                        . "<input type='hidden' name='flag' value='excluir'>"
                        . "<input type='submit' value='EXCLUIR'>"
                        . "</form>"
                       
                        . "<form action='../view/v_movimentacao.php' method='post'>"
                        . "<input type='hidden' name='id_movimentacao' value=".$this->get_id_movimentacao($i).">"
                        . "<input type='hidden' name='flag' value='editar'>"
                        . "<input type='submit' value='EDITAR'>"
                        . "</form>"
                    . "</center></td>";
		echo "</tr>";
	    }
	}
    }
	#acrescentar botao excluir e  update
   #echo "SELECT SUM((SELECT sum(valor) FROM `t_movimentacao` where tipo = 'CREDITO')-(SELECT sum(valor) FROM `t_movimentacao` where tipo = 'DEBITO'))valor_ FROM `t_movimentacao`;";
}

