<?php 
    require_once 'm_config.php';
    include('m_crud.php');
    $sql = new Dados;
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Trabalhando mysqli</title>
	</head>

	<body>
	    
	    <?php
	    $f['usuario']='maldito2';
	    $f['senha']='teste2';
	    
	    
		//var_dump(Dados::create('usuarios',$f));
		/*
		//if(Dados::create('usuarios', $f)){
		if($sql->create('usuarios', $f)){
		   echo "criado com sucesso"; 
		}
		*/
		//var_dump($sql->read('usuarios',"order by 'id' desc"));
		//$usuarios = $sql->read('usuarios',"order by 'id' desc");
		var_dump($usuarios = $sql->read('usuarios','where id :maldito2'));
		echo $usuarios['num'];
		echo '<hr>';
		
		foreach ($usuarios['dados'] as $each) {
		    echo $each['id']."<br>";
		    echo $each['usuario']."<br>";
		}
		echo '<hr>';
		$f['usuario']='carlos';
		//var_dump($sql->update('usuarios',$f,""));
		
		//var_dump($usuarios['dados']);
		$update = $sql->update('usuarios',$f,"id=95");
		
		if($update){
		    echo "Atualizado com sucesso";
		}
		
		$deletar = $sql->delete('usuarios','id=96');
		if($deletar){
		    echo "DELETADO COM SUCESSO";
		}
	    ?>
	    
	</body>

</html>