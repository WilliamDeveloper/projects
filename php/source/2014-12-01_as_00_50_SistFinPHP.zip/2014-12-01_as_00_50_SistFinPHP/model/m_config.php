<?php

$config = array(
	'host'=>'localhost',
	'user'=>'root',
	'pass'=>'',
	'dbsa'=>'ion'	
);

$conn = new mysqli(
	$config['host'],
	$config['user'],
	$config['pass'],
	$config['dbsa']
);

if(mysqli_connect_errno()){
    echo mysqli_connect_error();
}

