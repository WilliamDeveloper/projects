<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if($util->campo_valido($_POST['user']) &&
    $util->campo_valido($_POST['pw'])	
){
    $user = $_POST['user'];
    $pw = $_POST['pw'];
    
    $usuario = $sql->select("id_usuario,usuario,email,senha","t_usuario","where usuario ='$user' or email ='$user'");
    $id_usuario = $usuario['dados'][0]['id_usuario'];
    $nome = $usuario['dados'][0]['usuario'];
    $email = $usuario['dados'][0]['email'];
    $senha = $usuario['dados'][0]['senha'];
    #var_dump($nome);
    #var_dump($email);
    #var_dump($senha);
    #var_dump($user);
    #var_dump($pw);
    
    if($nome === $user){
    $file = "../model/Dados.txt";
    unlink($file);//deleta arquivos
    
    $file = "../model/id_Dados.txt";
    unlink($file);//deleta arquivos
    
    $file = fopen("../model/Dados.txt","a") or die("problemas ao criar");
    fwrite($file,"'$nome'\r\n");
    fclose($file);
    
    $file = fopen("../model/id_Dados.txt","a") or die("problemas ao criar");
    fwrite($file,"'$id_usuario'\r\n");
    fclose($file);

        if($senha === $pw){
            header("Location: ../view/v_inicio.php");
        }else{
            header("Location: ../view/v_login.php");
        }
	
    }else{
	header("Location: ../view/v_login.php");
    }

}else{
    #echo "problemas no envio do formulario";
    
                echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
        
        echo "<center>";
        echo "problemas no envio do formulario";
    
        echo    "<form id='theForm' action='../view/v_login.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'><br>          
            <label>Voltar a Tela de Login</label>        
        </a></form>";
        echo "</center>";
}