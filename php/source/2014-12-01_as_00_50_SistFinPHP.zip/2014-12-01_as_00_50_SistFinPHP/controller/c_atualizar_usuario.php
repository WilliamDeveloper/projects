<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if($util->campo_valido($_POST['email']) &&
    $util->campo_valido($_POST['usuario'])	&&
    $util->campo_valido($_POST['senha']) &&
    $util->campo_valido($_POST['confirm']) &&
    $util->campo_valido($_POST['id_usuario'])
){
    $dados['id_usuario']= $id_usuario = $_POST['id_usuario'];   
    $dados['usuario']= $_POST['usuario'];
    $dados['email']= $_POST['email'];   
    $dados['senha']= $_POST['senha']; 
    
  
    #var_dump($flag = $sql->update('t_usuario',$dados,"id_usuario = $id_usuario"));  
    $flag = $sql->update('t_usuario',$dados,"id_usuario = $id_usuario");  
        
    if($flag===true){
	echo "Dados atualizados com Sucesso!!!";
        
                      echo "<form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>"
                        . "<input type='hidden' name='flag' value='normal'>"
                        . "<script> document.theForm.submit();</script>"
                        . "</form>";
        
	#header("Location: ../view/v_usuario.php");
    }else{
        
                    echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
                    
        echo "<center>";
	echo "Dados Não Atualizados!!!";
        
         echo    "<form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Administração de Usuários</label>        
        </a></form>";
         echo "</center>";
    }

}else{
    #var_dump($_POST);
    
                echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
                
    echo "<center>";
    echo "problemas ao deletar";
    
            echo    "<form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Administração de Usuários</label>        
        </a></form>";
    echo "</center>";
}
    
    
    
    
    
//header("Location: ../view/v_inicio.php");

