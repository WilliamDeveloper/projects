<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if($util->campo_valido($_POST['tipo']) &&
    $util->campo_valido($_POST['data'])	&&
    $util->campo_valido($_POST['descricao']) &&
    $util->campo_valido($_POST['valor']) &&
    $util->campo_valido($_POST['categoria']) &&
	$util->campo_valido($_POST['i_usuario']) 
){
    
    
    $dados['data_movimento'] =$_POST['data'];
    $dados['tipo']=$_POST['tipo'];    
    $dados['descricao'] =$_POST['descricao'];
    $dados['valor'] =$_POST['valor'];
    $dados['categoria_id'] =$_POST['categoria'];
    $dados['usu_atu'] = $_POST['i_usuario'];
    $dados['dh_atu'] = date("Y-m-d");
    #var_dump(date("Y-m-d"));   
    
    #var_dump($dados);
    
    #echo "OKKKKK";
#    
#   $usuario = $sql->select("usuario,email","t_usuario","where usuario ='$user' or email ='$user'");
#   $nome = $usuario['dados'][0]['usuario'];
#    //var_dump($nome);
    #var_dump($maior_id = $sql->select("max(id_movimentacao) id_movimentacao","t_movimentacao",null));
    $maior_id = $sql->select("max(id_movimentacao) id_movimentacao","t_movimentacao",null);
    
    echo "<br><br><br>";
    #var_dump($dados['id_movimentacao']=($maior_id['dados'][0]['id_movimentacao']+1));
    $dados['id_movimentacao']=($maior_id['dados'][0]['id_movimentacao']+1);

    #var_dump($flag = $sql->create('t_movimentacao', $dados));  
    $flag = $sql->create('t_movimentacao', $dados);  
        
    if($flag===true){
	echo "Dados Inseridos Corretamente!!!";
	#header("Location: ../view/v_movimentacao.php");
        
                        echo "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>"
                        ."<input type='hidden' name='flag' value='normal'>"
                        . "<script> document.theForm.submit();</script>"
                        . "</form>";
        
    }else{
	#
        
                    echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
        
        echo "<center>";
        echo "Dados Inseridos INCORRETAMENTE!!!";            
                    
           echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'><br>          
            <label>Voltar a Tela de Movimentacao</label>        
        </a></form>";
       echo "</center>"; 
    }

}else{
    #var_dump($_POST);
    #
    
                    echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
        
        echo "<center>";
        echo "problemas ao inserir dados";            
                    
           echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'><br>          
            <label>Voltar a Tela de Movimentacao</label>        
        </a></form>";
        echo "</center>";
}
    
    
    
    
    
//header("Location: ../view/v_inicio.php");

