<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if(
    $util->campo_valido($_POST['id_movimentacao']) &&
    $util->campo_valido($_POST['tipo']) &&
    $util->campo_valido($_POST['data'])	&&
    $util->campo_valido($_POST['descricao']) &&
    $util->campo_valido($_POST['valor']) &&
    $util->campo_valido($_POST['categoria']) &&
    $util->campo_valido($_POST['i_usuario'])
   
){
    $id_movimentacao = $_POST['id_movimentacao'];   
    
    $dados['id_movimentacao']= $_POST['id_movimentacao'];
    $dados['data_movimento']= $_POST['data'];
    $dados['tipo']= $_POST['tipo'];
    $dados['descricao']= $_POST['descricao'];
    $dados['valor']= $_POST['valor'];
    $dados['categoria_id']= $_POST['categoria'];
    
    echo "<br><br><br>";
    #var_dump($dados);
    echo "<br><br><br>";

    #var_dump($flag2 = $sql->update('t_movimentacao',$dados,"id_movimentacao = $id_movimentacao"));  
    $flag2 = $sql->update('t_movimentacao',$dados,"id_movimentacao = $id_movimentacao");  
        
    if($flag2===true){
	echo "Dados atualizados com Sucesso!!!";
        
                      echo "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>"
                        . "<input type='hidden' name='flag' value='normal'>"
                        . "<script> document.theForm.submit();</script>"
                        . "</form>";
        
	#header("Location: ../view/v_usuario.php");
    }else{
        
                    echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
        
                    echo "<center>";
	echo "Dados Não atualizados!!!";
        
           echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Tela de movimentação</label>        
        </a></form>";
           echo "</center>";
    }

}else{
    #var_dump($_POST);
    
                echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
    
                echo "<center>";
    echo "problemas ao atualizar";
    
    
              echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Tela de movimentação</label>        
        </a></form>";
              echo "</center>";
}
    
    
    
    
    
//header("Location: ../view/v_inicio.php");

