<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if($util->campo_valido($_POST['excluir'])
){
    $id_movimentacao = $_POST['excluir'];
    
  
    #var_dump($flag = $sql->delete('t_movimentacao',"id_movimentacao = $id_movimentacao"));  
    $flag = $sql->delete('t_movimentacao',"id_movimentacao = $id_movimentacao"); 
        
    if($flag===true){
	echo "Dados Deletados com Sucesso!!!";
        
         echo "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>"
                        . "<input type='hidden' name='flag' value='normal'>"
                        . "<script> document.theForm.submit();</script>"
                        . "</form>";
        
                #header("Location: ../view/v_movimentacao.php");
    }else{
        
                    echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
                    
        echo "<center>";
	echo "Dados Não deletados!!!";
        
                echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Tela de movimentação</label>        
        </a></form>";
                echo "</center>";
    }

}else{
    #var_dump($_POST);
    
                echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
    
    echo "<center>";
    echo "problemas ao deletar";
    
     echo    "<form id='theForm' action='../view/v_movimentacao.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'>        
            <label>Voltar a Tela de movimentação</label>        
        </a></form>";
    echo "</center>";
    
}
    
    
    
    
    
//header("Location: ../view/v_inicio.php");

