<?php
echo "<meta charset='utf-8'>";

include ("../model/m_conexao.php");

if($util->campo_valido($_POST['email']) &&
    $util->campo_valido($_POST['usuario'])	&&
    $util->campo_valido($_POST['senha']) &&
    $util->campo_valido($_POST['confirm']) 
){
    #var_dump($maior_id = $sql->select("max(id_usuario) id_usuario","t_usuario",null));
     $maior_id = $sql->select("max(id_usuario) id_usuario","t_usuario",null);
   
    
    $dados['id_usuario']=($maior_id['dados'][0]['id_usuario']+1);
    $dados['usuario']=$_POST['usuario'];
    $dados['email'] =$_POST['email'];
    $dados['senha'] =$_POST['senha'];
    $dados['usu_atu'] = "CADASTRO";
    $dados['dh_atu'] = date("Y-m-d");
    //var_dump(date("Y-m-d"));    
    if($sql->create('t_usuario', $dados)===true){
	#echo "Dados Inseridos Corretamente!!!";
	#header("Location: ../view/v_movimentacao.php");
        if($util->campo_valido($_POST['reg_admin'])){
            
            if($_POST['reg_admin']=== 'reg_admin'){
                echo "<form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>"
                        . "<input type='hidden' name='flag' value='normal'>"
                        . "<script> document.theForm.submit();</script>"
                        . "</form>";
            }else{
                
                echo "<table width='100%'><tr>
                <td width='8%' height='114'>
                <center> 
                <img src='../img/logo.png' width='70' height='52'  alt=''/>    
                </center>
                </td>
                <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
                </td></tr></table><br><hr>";

                echo "<center>";
                echo "Usuario Registrado com Sucesso";            

                   echo    "<form id='theForm' action='../view/v_login.php' name='theForm' method='post'>
                <input type='hidden' name='flag' value='normal'>        
                <a href='javascript:document.theForm.submit();'><br>          
                    <label>Voltar a Tela de Login</label>        
                </a></form>";
                echo "</center>";
                
                
                #header("Location: ../view/v_login.php");
            }
                       
            #header("Location: ../view/v_usuario.php");
        }else{
            #echo "<br><br><a href='../view/v_login.php'>Retornar ao Login</a>";
            header("Location: ../view/v_login.php");
        }
	
	
    }else{
	#
                echo "<table width='100%'><tr>
                <td width='8%' height='114'>
                <center> 
                <img src='../img/logo.png' width='70' height='52'  alt=''/>    
                </center>
                </td>
                <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
                </td></tr></table><br><hr>";

                echo "<center>";
                echo "Usuario ou Email já existem!!!";
                
           if($_POST['reg_admin']=== 'reg_admin'){ 
               
                echo    "<form id='theForm2' action='../view/v_usuario.php' name='theForm2' method='post'>
                <input type='hidden' name='flag' value='normal'>        
                <a href='javascript:document.theForm2.submit();'><br>          
                    <label>Voltar a Tela Administração de usuarios</label>        
                </a></form>";
                echo "</center>";

           }else{


                 echo    "<form id='theForm' action='../view/v_registrar.php' name='theForm' method='post'>
                <input type='hidden' name='flag' value='normal'>        
                <a href='javascript:document.theForm.submit();'><br>          
                    <label>Voltar a Tela cadastro de Usuarios</label>        
                </a></form><br>";

                echo    "<form id='theForm2' action='../view/v_recuperar.php' name='theForm2' method='post'>
                <input type='hidden' name='flag' value='normal'>        
                <a href='javascript:document.theForm2.submit();'><br>          
                    <label>Voltar a Tela Recuperar Senha</label>        
                </a></form>";
                echo "</center>";
           }
    }

}else{
    #
    if($util->campo_valido($_POST['reg_admin'])){
        if($_POST['reg_admin']==='reg_admin'){
            
                        echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
            
            echo "<center>";
            echo "Problemas ao tentar cadastrar o usuario na tela de administracao de usuario";
            
                       echo    "<form id='theForm' action='../view/v_usuario.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'> <br>       
            <label>Voltar a Tela Administracao de Usuarios</label>        
        </a></form>";
         echo "</center>";
         
        }else{
            
            echo "<table width='100%'><tr>
            <td width='8%' height='114'>
            <center> 
            <img src='../img/logo.png' width='70' height='52'  alt=''/>    
            </center>
            </td>
            <td width='72%' style='font-size: 36px; font-style: normal; font-weight: bold;'> Sistema Financeiro</td>
            </td></tr></table><br><hr>";
            
            echo "<center>";
            echo "Problemas ao tentar cadastrar o usuario";
            
             echo    "<form id='theForm' action='../view/v_registrar.php' name='theForm' method='post'>
        <input type='hidden' name='flag' value='normal'>        
        <a href='javascript:document.theForm.submit();'> <br>       
            <label>Voltar a Tela Registro de Usuarios</label>        
        </a></form>";
             echo "</center>";
            
        }
        
    }
                 
    
    

    
}


	//header("Location: ../view/v_movimentacao.php");
   
    
    
    
    
//header("Location: ../view/v_inicio.php");

