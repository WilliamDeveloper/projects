
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Pagina Login</title>
</head>

<body>
<?php header("Location: view/v_login.php"); ?>

</body>
</html>
