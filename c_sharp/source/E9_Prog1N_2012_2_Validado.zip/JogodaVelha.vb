﻿Public Class JogodaVelha
    Sub impossibilitatroca()
        radio_o.Enabled = False
        radio_x.Enabled = False
    End Sub

    Sub funcao_desabilita()
        b1.Enabled = False
        b2.Enabled = False
        b3.Enabled = False
        b4.Enabled = False
        b5.Enabled = False
        b6.Enabled = False
        b7.Enabled = False
        b8.Enabled = False
        b9.Enabled = False
    End Sub

    Sub funcao_reset()
        b1.Text = ""
        b2.Text = ""
        b3.Text = ""
        b4.Text = ""
        b5.Text = ""
        b6.Text = ""
        b7.Text = ""
        b8.Text = ""
        b9.Text = ""
        b1.Enabled = True
        b2.Enabled = True
        b3.Enabled = True
        b4.Enabled = True
        b5.Enabled = True
        b6.Enabled = True
        b7.Enabled = True
        b8.Enabled = True
        b9.Enabled = True
        radio_o.Enabled = True
        radio_x.Enabled = True
    End Sub

    Sub ganhador()
        If (
            b1.Text = "X" And b2.Text = "X" And b3.Text = "X" Or
            b4.Text = "X" And b5.Text = "X" And b6.Text = "X" Or
            b7.Text = "X" And b8.Text = "X" And b9.Text = "X" Or
            b1.Text = "X" And b4.Text = "X" And b7.Text = "X" Or
            b2.Text = "X" And b5.Text = "X" And b8.Text = "X" Or
            b3.Text = "X" And b6.Text = "X" And b9.Text = "X" Or
            b1.Text = "X" And b5.Text = "X" And b9.Text = "X" Or
            b7.Text = "X" And b5.Text = "X" And b3.Text = "X") Then
            MsgBox("Ganhador X!")
            funcao_desabilita()
        ElseIf (
            b1.Text = "O" And b2.Text = "O" And b3.Text = "O" Or
            b4.Text = "O" And b5.Text = "O" And b6.Text = "O" Or
            b7.Text = "O" And b8.Text = "O" And b9.Text = "O" Or
            b1.Text = "O" And b4.Text = "O" And b7.Text = "O" Or
            b2.Text = "O" And b5.Text = "O" And b8.Text = "O" Or
            b3.Text = "O" And b6.Text = "O" And b9.Text = "O" Or
            b1.Text = "O" And b5.Text = "O" And b9.Text = "O" Or
            b7.Text = "O" And b5.Text = "O" And b3.Text = "O") Then
            MsgBox("Ganhador O!")
            funcao_desabilita()
        ElseIf (b1.Enabled = False And
                b2.Enabled = False And
                b3.Enabled = False And
                b4.Enabled = False And
                b5.Enabled = False And
                b6.Enabled = False And
                b7.Enabled = False And
                b8.Enabled = False And
                b9.Enabled = False) Then
            MsgBox("Não Houve Ganhador!")

        End If

    End Sub
    Private Sub b1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b1.Click
        If (radio_x.Checked = True) Then
            b1.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b1.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b1.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b2.Click
        If (radio_x.Checked = True) Then
            b2.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b2.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b2.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b3.Click
        If (radio_x.Checked = True) Then
            b3.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b3.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b3.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b4.Click
        If (radio_x.Checked = True) Then
            b4.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b4.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b4.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b5.Click
        If (radio_x.Checked = True) Then
            b5.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b5.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b5.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b6.Click
        If (radio_x.Checked = True) Then
            b6.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b6.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b6.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b7.Click
        If (radio_x.Checked = True) Then
            b7.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b7.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b7.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b8.Click
        If (radio_x.Checked = True) Then
            b8.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b8.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b8.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub b9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles b9.Click
        If (radio_x.Checked = True) Then
            b9.Text = "X"
            radio_o.Checked = True
            radio_x.Checked = False
        Else
            b9.Text = "O"
            radio_x.Checked = True
            radio_o.Checked = False
        End If
        b9.Enabled = False
        impossibilitatroca()
        ganhador()
    End Sub

    Private Sub newgame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles newgame.Click
        funcao_reset()
    End Sub


End Class
