﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class JogodaVelha
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.b1 = New System.Windows.Forms.Button()
        Me.b2 = New System.Windows.Forms.Button()
        Me.b3 = New System.Windows.Forms.Button()
        Me.b6 = New System.Windows.Forms.Button()
        Me.b5 = New System.Windows.Forms.Button()
        Me.b4 = New System.Windows.Forms.Button()
        Me.b9 = New System.Windows.Forms.Button()
        Me.b8 = New System.Windows.Forms.Button()
        Me.b7 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.radio_x = New System.Windows.Forms.RadioButton()
        Me.radio_o = New System.Windows.Forms.RadioButton()
        Me.newgame = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'b1
        '
        Me.b1.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b1.ForeColor = System.Drawing.Color.OrangeRed
        Me.b1.Location = New System.Drawing.Point(76, 48)
        Me.b1.Name = "b1"
        Me.b1.Size = New System.Drawing.Size(55, 55)
        Me.b1.TabIndex = 0
        Me.b1.UseVisualStyleBackColor = True
        '
        'b2
        '
        Me.b2.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b2.ForeColor = System.Drawing.Color.OrangeRed
        Me.b2.Location = New System.Drawing.Point(137, 48)
        Me.b2.Name = "b2"
        Me.b2.Size = New System.Drawing.Size(55, 55)
        Me.b2.TabIndex = 1
        Me.b2.UseVisualStyleBackColor = True
        '
        'b3
        '
        Me.b3.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b3.ForeColor = System.Drawing.Color.OrangeRed
        Me.b3.Location = New System.Drawing.Point(198, 48)
        Me.b3.Name = "b3"
        Me.b3.Size = New System.Drawing.Size(55, 55)
        Me.b3.TabIndex = 2
        Me.b3.UseVisualStyleBackColor = True
        '
        'b6
        '
        Me.b6.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b6.ForeColor = System.Drawing.Color.OrangeRed
        Me.b6.Location = New System.Drawing.Point(198, 109)
        Me.b6.Name = "b6"
        Me.b6.Size = New System.Drawing.Size(55, 55)
        Me.b6.TabIndex = 5
        Me.b6.UseVisualStyleBackColor = True
        '
        'b5
        '
        Me.b5.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b5.ForeColor = System.Drawing.Color.OrangeRed
        Me.b5.Location = New System.Drawing.Point(137, 109)
        Me.b5.Name = "b5"
        Me.b5.Size = New System.Drawing.Size(55, 55)
        Me.b5.TabIndex = 4
        Me.b5.UseVisualStyleBackColor = True
        '
        'b4
        '
        Me.b4.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b4.ForeColor = System.Drawing.Color.OrangeRed
        Me.b4.Location = New System.Drawing.Point(76, 109)
        Me.b4.Name = "b4"
        Me.b4.Size = New System.Drawing.Size(55, 55)
        Me.b4.TabIndex = 3
        Me.b4.UseVisualStyleBackColor = True
        '
        'b9
        '
        Me.b9.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b9.ForeColor = System.Drawing.Color.OrangeRed
        Me.b9.Location = New System.Drawing.Point(198, 170)
        Me.b9.Name = "b9"
        Me.b9.Size = New System.Drawing.Size(55, 55)
        Me.b9.TabIndex = 8
        Me.b9.UseVisualStyleBackColor = True
        '
        'b8
        '
        Me.b8.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b8.ForeColor = System.Drawing.Color.OrangeRed
        Me.b8.Location = New System.Drawing.Point(137, 170)
        Me.b8.Name = "b8"
        Me.b8.Size = New System.Drawing.Size(55, 55)
        Me.b8.TabIndex = 7
        Me.b8.UseVisualStyleBackColor = True
        '
        'b7
        '
        Me.b7.Font = New System.Drawing.Font("Arial Black", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.b7.ForeColor = System.Drawing.Color.OrangeRed
        Me.b7.Location = New System.Drawing.Point(76, 170)
        Me.b7.Name = "b7"
        Me.b7.Size = New System.Drawing.Size(55, 55)
        Me.b7.TabIndex = 6
        Me.b7.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 15.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(71, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(210, 29)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "JOGO DA VELHA !!!"
        '
        'radio_x
        '
        Me.radio_x.AutoSize = True
        Me.radio_x.Checked = True
        Me.radio_x.Location = New System.Drawing.Point(21, 48)
        Me.radio_x.Name = "radio_x"
        Me.radio_x.Size = New System.Drawing.Size(32, 17)
        Me.radio_x.TabIndex = 10
        Me.radio_x.TabStop = True
        Me.radio_x.Text = "X"
        Me.radio_x.UseVisualStyleBackColor = True
        '
        'radio_o
        '
        Me.radio_o.AutoSize = True
        Me.radio_o.Location = New System.Drawing.Point(20, 71)
        Me.radio_o.Name = "radio_o"
        Me.radio_o.Size = New System.Drawing.Size(33, 17)
        Me.radio_o.TabIndex = 11
        Me.radio_o.Text = "O"
        Me.radio_o.UseVisualStyleBackColor = True
        '
        'newgame
        '
        Me.newgame.Location = New System.Drawing.Point(76, 255)
        Me.newgame.Name = "newgame"
        Me.newgame.Size = New System.Drawing.Size(177, 23)
        Me.newgame.TabIndex = 12
        Me.newgame.Text = "NOVO JOGO !"
        Me.newgame.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(219, 281)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 25)
        Me.Label2.TabIndex = 13
        '
        'JogodaVelha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(327, 314)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.newgame)
        Me.Controls.Add(Me.radio_o)
        Me.Controls.Add(Me.radio_x)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.b9)
        Me.Controls.Add(Me.b8)
        Me.Controls.Add(Me.b7)
        Me.Controls.Add(Me.b6)
        Me.Controls.Add(Me.b5)
        Me.Controls.Add(Me.b4)
        Me.Controls.Add(Me.b3)
        Me.Controls.Add(Me.b2)
        Me.Controls.Add(Me.b1)
        Me.MaximizeBox = False
        Me.Name = "JogodaVelha"
        Me.Text = "Jogo_Da_Velha(William Goulart Pacheco)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents b1 As System.Windows.Forms.Button
    Friend WithEvents b2 As System.Windows.Forms.Button
    Friend WithEvents b3 As System.Windows.Forms.Button
    Friend WithEvents b6 As System.Windows.Forms.Button
    Friend WithEvents b5 As System.Windows.Forms.Button
    Friend WithEvents b4 As System.Windows.Forms.Button
    Friend WithEvents b9 As System.Windows.Forms.Button
    Friend WithEvents b8 As System.Windows.Forms.Button
    Friend WithEvents b7 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents radio_x As System.Windows.Forms.RadioButton
    Friend WithEvents radio_o As System.Windows.Forms.RadioButton
    Friend WithEvents newgame As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
