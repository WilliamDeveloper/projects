
package br.com.util.file;

public class AbsolutoPositivo {
    public static void main(String[] args) {
        System.out.println(""+Math.abs(-122323));
    }
}
