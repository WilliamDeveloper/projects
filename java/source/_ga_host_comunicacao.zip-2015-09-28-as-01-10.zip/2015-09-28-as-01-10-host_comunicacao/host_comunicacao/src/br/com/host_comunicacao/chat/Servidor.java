package br.com.host_comunicacao.chat;


import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

public class Servidor implements Runnable{	 
	     
	   private boolean inicializado;
	   private boolean executando;
	   private int qtdMaxConexao;
	   private int contMaxConexao;
	   private List<InformaNovaMsgDoCliente> listaInformanteNovaMsg;
	   private ServerSocket socketServidor;
	   private Thread threadServidor;
	   
	   

//######################################################################################
	   public Servidor (int porta,int qtdMaxConexao) throws Exception {
		 this.listaInformanteNovaMsg = new ArrayList<InformaNovaMsgDoCliente>();
	     this.inicializado = false;
	     this.executando = false;
	     this.qtdMaxConexao = qtdMaxConexao;
	     this.contMaxConexao = 0;
	     abrirConexao(porta);	     
	   }

//######################################################################################	   
	   public void abrirConexao(int porta) throws Exception{
		   if(this.qtdMaxConexao > 0){
			   this.socketServidor = new ServerSocket(porta,1);
			   this.inicializado = true;
		   }
	   }
	   
//######################################################################################	   
	   public void fecharConexao(){
		   for(InformaNovaMsgDoCliente informanteNovaMsg :this.listaInformanteNovaMsg){
			   try{
				   informanteNovaMsg.stop();
			   }catch(Exception e){
				   //System.out.println(e);
			   }
		   }
					   
		   try {
				socketServidor.close();
		   } catch (Exception e) {
				System.out.println(e);
		   }
		   this.inicializado = false;
		   this.executando = false;
		   this.socketServidor = null;
		   this.threadServidor = null;	
		   this.qtdMaxConexao = 0;
		   this.contMaxConexao = 0;
	   }
	   
//######################################################################################
	   public void start(){
		   if(this.inicializado == false || this.executando == true){
			   return;
		   }
		   this.executando = true;
		   this.threadServidor = new Thread(this);
		   this.threadServidor.start();
	   }
	   
//######################################################################################
	   public void stop() throws Exception{
		   this.executando = false;
       //faz a thread X(Main) esperar a thread Y(Servidor) morrer para seguir
		   if(threadServidor != null){
			   this.threadServidor.join();
		   }		  
	   }

//######################################################################################
	   public void imprimirConexaoAtivas(){
		   System.out.println("Total de conexoes ativas: "+this.contMaxConexao+" de "+this.qtdMaxConexao);
	   }
//######################################################################################
	   public void enviaMensagemTodos(String mensagem){
		   for(InformaNovaMsgDoCliente informanteNovaMsg :this.listaInformanteNovaMsg){
			   if(informanteNovaMsg.isRodando()){
				   informanteNovaMsg.recebeMsg(mensagem);   
			   }			   
		   }
	   }
//######################################################################################
		@Override
		public void run() {
			System.out.println("Aguardando Conex�o.");
			while(this.executando == true){

					try {
						
						this.socketServidor.setSoTimeout(2500);//set timeout 2,5 segundos
						if(this.contMaxConexao < this.qtdMaxConexao){							
							
							//o accept() pausa a execu��o ateh q o servidor receba um pedido de conex�o
							Socket socketCliente = socketServidor.accept();
																			
							this.aumentaContMaxConexao();
							System.out.println("Conex�o Estabelecida");
							this.imprimirConexaoAtivas();						
							InformaNovaMsgDoCliente informanteNovaMsg = new InformaNovaMsgDoCliente(socketCliente,this);
							informanteNovaMsg.start();
							this.listaInformanteNovaMsg.add(informanteNovaMsg);
						}else{
							Socket socketCliente = socketServidor.accept();
							socketCliente.close();							
						}
					} catch(IOException e){
						//ignorar
					} catch (Exception e) {
						System.out.println(e);
						break;
					}			
				}

			this.fecharConexao();			
		}
//######################################################################################
public static Integer getPorta(){
	String entrada = "0";
	boolean naoTemErro = false;
	
	Pattern padraoValido = Pattern.compile( "\\d+" );
	Matcher validador = null;

	while(naoTemErro == false){
			String mensagemDaCaixaDeDialogo = "Informe em qual porta o servidor ir� Atender: ";
			System.out.println(mensagemDaCaixaDeDialogo);
			entrada = JOptionPane.showInputDialog(null, mensagemDaCaixaDeDialogo);
			validador = padraoValido.matcher(entrada);
			naoTemErro = validador.matches();			
	}
	
	return Integer.valueOf(entrada);
}
		
//######################################################################################
public static Integer getNrMaxConexao(){
	String entrada = "0";
	boolean naoTemErro = false;

	Pattern padraoValido = Pattern.compile( "\\d+" );
	Matcher validador = null;

	while(naoTemErro == false){
			String mensagemDaCaixaDeDialogo = "Informe o n�mero m�ximo de conex�es em ser�o atendidas: ";
			System.out.println(mensagemDaCaixaDeDialogo);
			entrada = JOptionPane.showInputDialog(null, mensagemDaCaixaDeDialogo);
			validador = padraoValido.matcher(entrada);
			naoTemErro = validador.matches();			
	}
	
	return Integer.valueOf(entrada);
}
//######################################################################################
public void diminuiContMaxConexao(){
	if(this.contMaxConexao > 0){
		this.contMaxConexao--;
	}
}
//######################################################################################
public void aumentaContMaxConexao(){
	if(this.contMaxConexao < this.qtdMaxConexao){
		this.contMaxConexao++;
	}
}

//######################################################################################
	   public static void main(String[] args) throws Exception {
		   
		   Integer v_porta = 0;
		   Integer v_qtd_max_conexao = 0;
		   Scanner teclado = new Scanner(System.in);
		   
		   v_porta = Servidor.getPorta();
		   
		   while(v_qtd_max_conexao == 0){
			   v_qtd_max_conexao = Servidor.getNrMaxConexao();
		   }		   
		   
		   System.out.println("Iniciando Servidor");
		   
		   Servidor servidor = new Servidor(v_porta,v_qtd_max_conexao);
		   servidor.start();
		   
		   System.out.println("Servidor Iniciado na porta: "+v_porta);
		   System.out.println("Digite FIM para finalizar o servidor.");
		   
		   String mensagem ;
		   do{
			   mensagem = teclado.nextLine();
			   servidor.enviaMensagemTodos(mensagem);
		
		   } while(mensagem.equals("FIM") == false);
		   
		   
		   System.out.println("Finalizando o Servidor.");
		   servidor.stop();
		   teclado.close();
	   }

	   

	 }