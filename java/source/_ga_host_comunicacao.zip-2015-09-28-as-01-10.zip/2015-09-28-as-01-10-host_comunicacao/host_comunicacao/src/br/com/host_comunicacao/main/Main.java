package br.com.host_comunicacao.main;

import java.util.Scanner;

import br.com.host_comunicacao.util.LeitorDeArquivo;

public class Main {

	public static void main(String[] args) {

		System.out.print("TESTE");
		
		
		
		
	}
}
