package br.com.host_comunicacao.chat;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import br.com.host_comunicacao.propriedades.Propriedades;
import br.com.host_comunicacao.util.Comando;
import br.com.host_comunicacao.util.LeitorDeArquivo;

public class Cliente implements Runnable{   
  private Socket socketCliente;
  private BufferedReader inputVindoDoServidor;
  private PrintStream outputVindoDoServidor;
  private InputStream servidorInput;
  private OutputStream servidorOutput;
  private boolean inicializado;
  private boolean executando;
  private boolean bloqueiaEnvioMensagem;
  private Thread threadCliente;
	
  private String clienteNomeHost;
  private String clientePortaHost;
  private String clienteIpHost;
  private String servidorIpHost;
  private String servidorPortaHost;
  private String servidorNomeHost;
  private Comando comando;
  
//######################################################################################
  public Cliente (String endereco, int porta) throws Exception {
    this.inicializado = false;
    this.executando = false;
    this.bloqueiaEnvioMensagem = true;
    this.abrirConexao(endereco,porta);
  }

//######################################################################################
  private void abrirConexao(String endereco, int porta) throws Exception{
	try{
	  this.socketCliente = new Socket(endereco, porta);
	  this.servidorInput = this.socketCliente.getInputStream();
	  this.servidorOutput = this.socketCliente.getOutputStream();
	  this.inputVindoDoServidor = new BufferedReader(new InputStreamReader(this.servidorInput));
	  this.outputVindoDoServidor = new PrintStream(this.servidorOutput);
	  this.inicializado = true;
	  this.bloqueiaEnvioMensagem = false;
	  	
	  	this.servidorNomeHost = this.socketCliente.getInetAddress().getHostName();
		this.servidorPortaHost = Integer.toString(socketCliente.getPort());
		this.servidorIpHost = socketCliente.getInetAddress().getHostAddress();
		
		this.clienteIpHost = socketCliente.getLocalAddress().getHostAddress();
		this.clientePortaHost = Integer.toString(this.socketCliente.getLocalPort());
		this.clienteNomeHost = socketCliente.getLocalAddress().getHostName();
	}catch(ConnectException e){
		System.out.println("Servidor n�o encontrado!");
	
	}catch(Exception e){
		System.out.println(e);
		this.fecharConexao();
		throw e;
	}
  }
  
//######################################################################################
  private void fecharConexao(){
	  if(this.inputVindoDoServidor != null){
		  try{ 
			  this.inputVindoDoServidor.close();
		  }catch(Exception e){  
			  System.out.println(e);   
		  }		  
	  }
	  
	  if(this.outputVindoDoServidor != null){
		  try{ 	
			  this.outputVindoDoServidor.close();
		  }catch(Exception e){
			  System.out.println(e);
		  }		  
	  }
	  
	  if(this.socketCliente != null){
		  try{
			  this.socketCliente.close();
		  }catch(Exception e){
			  System.out.println(e);
		  }		  
	  }
	  
	  if(this.servidorInput != null){
		  try {
			this.servidorInput.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	  }
	  
	  if(this.servidorOutput != null){
		  try {
			this.servidorOutput.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	  }
	  
	  this.inicializado = false;
	  this.executando = false;
	  this.bloqueiaEnvioMensagem = true;
	  this.inputVindoDoServidor = null;
	  this.outputVindoDoServidor = null;
	  this.socketCliente = null;
	  this.threadCliente = null;	  
	  this.servidorInput = null;
	  this.servidorOutput = null;
  }

//######################################################################################
  public void start(){
	   if(this.inicializado == false || this.executando == true){
		   return;
	   }
	   this.executando = true;
	   this.threadCliente = new Thread(this);
	   this.threadCliente.start();
  }
  
//######################################################################################
  public void stop() throws Exception{
	   this.executando = false;	   
	   if(threadCliente != null){
		 //faz a thread X(Main) esperar a thread Y(Cliente) morrer para seguir
		   this.threadCliente.join();   
	   }	   
  }
  
//######################################################################################
  public boolean isExecutando(){
	  return this.executando;
  }
  
//######################################################################################
  public void send(String mensagem){
	  this.outputVindoDoServidor.println(mensagem);
	  this.outputVindoDoServidor.flush();
	  
  }
  
//######################################################################################  
  @Override
  public void run() {
  	while(executando == true){
  		try {
			  			
  			String mensagem = this.inputVindoDoServidor.readLine();
		
			if(mensagem == null){
				break;
			}
			
			if(Propriedades._ARQUIVO_ENCONTRADO_.equals(mensagem)){
				 this.bloquearEnvioMensagem();
				 new ClienteReceberArquivo(this,this.comando.getArquivo()).start();				
			}else{
				System.out.println(mensagem);//pega o que o servidor diz
			}
			//System.out.println("["+this.servidorIpHost+":"+this.servidorPortaHost+"]{"+this.servidorNomeHost+"}: "+mensagem);
  			
			
  		} catch (SocketTimeoutException e) {
			//ignorar
  			System.out.println("io-");//nunca imprimi
		} catch (Exception e) {
			//System.out.println(e);
			break;
		}
  	}
  	this.fecharConexao();
  }
 
//######################################################################################
  public static Integer getPorta(){
		String entrada = "0";
		boolean naoTemErro = false;
		
		Pattern padraoValido = Pattern.compile( "\\d+" );
		Matcher validador = null;

		while(naoTemErro == false){
				String mensagemDaCaixaDeDialogo = "Informe qual a porta do servidor: ";
				System.out.println(mensagemDaCaixaDeDialogo);
				entrada = JOptionPane.showInputDialog(null, mensagemDaCaixaDeDialogo);
				validador = padraoValido.matcher(entrada);
				naoTemErro = validador.matches();			
		}
		
		return Integer.valueOf(entrada);
	}
			
//######################################################################################
  public static String getNomeServidor(){
		String mensagemDaCaixaDeDialogo = "Informe o ip ou nome do servidor: ";
		return JOptionPane.showInputDialog(null, mensagemDaCaixaDeDialogo);
	}
			
//######################################################################################
public void receberArquivo(String nome){
	
	nome = nome.trim();
	LeitorDeArquivo leitor = new LeitorDeArquivo(Propriedades._PASTA_CLIENTE_+nome);
	leitor.crearArquivo();	
	
	File file =  leitor.getArquivo();
		
	BufferedInputStream bis = new BufferedInputStream(this.servidorInput);
	BufferedOutputStream bos = new BufferedOutputStream(this.servidorOutput);
	FileOutputStream escreveNoArquivo = null;
	try {
		//this.socketCliente.setSoTimeout(0);
		escreveNoArquivo = new FileOutputStream(file);
		int totalByteLidos;
		byte[] bufferBytesLidos = new byte[1024];
		
		while((totalByteLidos = bis.read(bufferBytesLidos,0,1024)) != -1){
					
			escreveNoArquivo.write(bufferBytesLidos, 0, totalByteLidos);
			//System.out.println(""+totalByteLidos+" "+bufferBytesLidos.toString());
			//System.out.println(this.socketCliente.getReceiveBufferSize());
			//System.out.print(new String(bufferBytesLidos, 0, bufferBytesLidos.length, "ISO8859_1"));
			bos.flush();
		}
		bos.flush();
		System.out.println("saiu");
		//escreveNoArquivo.flush();
		//escreveNoArquivo.close();
		//bis.close();
		//this.socketCliente.setSoTimeout(2500);	
	} catch (FileNotFoundException e) {		
			System.out.println("Arquivo n�o foi encontrado");
	} catch (IOException e) {
		
			try { escreveNoArquivo.close(); } catch (IOException e1) {	}	
			//try { bis.close(); } catch (IOException e2) {	}
			escreveNoArquivo = null;
			bis = null;
			leitor.deleteArquivo();
			System.out.println("Arquivo N�o encontrado No Servidor!");
			System.out.println("Ocorreu erro de I/O!!");
	}	

	
}  

public void bloquearEnvioMensagem(){
	this.bloqueiaEnvioMensagem = true;
}

public void desbloquearEnvioMensagem(){
	this.bloqueiaEnvioMensagem = false;
}

public boolean isBloqueiaEnvioMensagem(){
	return this.bloqueiaEnvioMensagem;
}
  
//######################################################################################
  
  public static void main(String[] args) throws Exception {
	  
	  String v_nome_servidor = Cliente.getNomeServidor();
	  Integer v_porta = Cliente.getPorta();	  

	  System.out.println("Inicializando cliente ...");
	  System.out.println("Conectando com o servidor ...");
	  
	  //Cliente cliente = new Cliente("localhost", 12345);
	  Cliente cliente = new Cliente(v_nome_servidor, v_porta);
	  cliente.start();
	  	  
	  try {
		    Thread.sleep(5*000);
		} catch(InterruptedException ex) {
		    Thread.currentThread().interrupt();
		}
	  
     if(cliente.isExecutando() == false){

		  System.out.println("N�o foi possivel conectar!");		  
		  
	  }else{
		  
		  System.out.println("Conex�o estabelecida com sucesso ...");
		  
		  Scanner teclado = new Scanner(System.in);
		  String mensagem = " ";

		  
		  while (true) {
			  try{
						
				  System.out.println("Digite uma mensagem: ");
				  mensagem = teclado.nextLine();
				  
				  cliente.comando = new Comando(mensagem);
				  cliente.send(mensagem);
				
				if(cliente.isExecutando() == false){
					break;
				}
				
				if("FIM".equals(mensagem)){
					break;
				}
				

				
			  }catch(Exception e){
				  
			  }
		  				
		}
		  System.out.println("Finalizando cliente ...");
		  cliente.stop();
		  teclado.close();
		  System.out.println("A conex�o com o Servidor foi finalizada!");	  
		  
		  
	  }	  
	  

  }

}