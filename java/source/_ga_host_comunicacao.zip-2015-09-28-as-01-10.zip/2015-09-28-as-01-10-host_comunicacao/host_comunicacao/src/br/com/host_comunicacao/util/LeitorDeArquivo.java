package br.com.host_comunicacao.util;

import java.io.File;
import java.io.IOException;


public class LeitorDeArquivo {
	private File arquivo;
	
	public LeitorDeArquivo(String nomeDoArquivo) {
		nomeDoArquivo = (nomeDoArquivo == null)?"":nomeDoArquivo;
		this.arquivo = new File(nomeDoArquivo);
	}	
	//######################################################################################

	public boolean temArquivo(){
		return arquivo.exists();
	} 
	//######################################################################################
	
	public boolean deleteArquivo(){
		return arquivo.delete();
	} 
	//######################################################################################
	
	public void crearArquivo(){
		if(this.temArquivo() == true){
			this.deleteArquivo();
		}
		
		try {
				this.arquivo.createNewFile();
		} catch (IOException e) {
				System.out.println("N�o foi possivel criar o arquivo!");
		}
	}
	//######################################################################################	
	public File getArquivo(){
		return this.arquivo;
	}

	//######################################################################################
	
	public boolean validaCaminhoArquivoOK() {
	    try {
	       this.arquivo.getCanonicalPath();
	       //System.out.println("caminho : "+this.arquivo.getCanonicalPath());	
	       //System.out.println("- "+this.arquivo.getPath());
	       
	       if(temArquivo() == false){
	    	   return false;
	       }
	       
	       return true;
	       
	    }
	    catch (IOException e) {
	       return false;
	    }
	  }
	
	//######################################################################################
	
	public static void main(String[] args) {
		String PASTA_PADRAO_DE_ARQUIVOS = "src/br/com/host_comunicacao/arquivos/";
		//LeitorDeArquivo leitor = new LeitorDeArquivo(PASTA_PADRAO_DE_ARQUIVOS+"*txt-texto5.txt sad");
		LeitorDeArquivo leitor = new LeitorDeArquivo(PASTA_PADRAO_DE_ARQUIVOS+"");
		leitor.crearArquivo();
		//System.out.println("".isEmpty());
		System.out.println(leitor.validaCaminhoArquivoOK());
		
	}

	
}