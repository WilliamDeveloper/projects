package br.com.host_comunicacao.chat;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.SocketTimeoutException;

import br.com.host_comunicacao.propriedades.Propriedades;
import br.com.host_comunicacao.util.Comando;
import br.com.host_comunicacao.util.LeitorDeArquivo;

public class InformaNovaMsgDoCliente implements Runnable {
	private Socket socketCliente;
	private BufferedReader 	inputVindoDoCliente;
	private PrintStream 	outputVindoDoCliente;	
	private BufferedOutputStream saidaDoCliente;
	private InputStream clienteInput;
	private OutputStream clienteOutput;
	private String clienteNomeHost;
	private String clientePortaHost;
	private String clienteIpHost;
	private String servidorIpHost;
	private String servidorPortaHost;
	private String servidorNomeHost;
	private Servidor servidor;
	private boolean inicializado;
	private boolean executando;	
	private boolean envioMensagem;
	private Comando comando;
	private FileInputStream arquivoFisico;
	private Thread thread;
	
//######################################################################################
	public InformaNovaMsgDoCliente(Socket socket,Servidor servidor) throws Exception{
		this.socketCliente = socket;
		this.servidor = servidor;
		this.inicializado = false;
		this.executando   = false;
		this.envioMensagem = false;
		this.abrir();
	}
	
//######################################################################################
	public void abrir() throws Exception{
		try{
			this.clienteInput = this.socketCliente.getInputStream();
			this.clienteOutput = this.socketCliente.getOutputStream();
			this.inputVindoDoCliente  = new BufferedReader(new InputStreamReader(this.clienteInput));
			this.outputVindoDoCliente = new PrintStream(this.clienteOutput);
			this.inicializado = true;
			
			this.clienteNomeHost = this.socketCliente.getInetAddress().getHostName();
			this.clientePortaHost = Integer.toString(socketCliente.getPort());
			this.clienteIpHost = socketCliente.getInetAddress().getHostAddress();
			
			this.servidorIpHost = socketCliente.getLocalAddress().getHostAddress();
			this.servidorPortaHost = Integer.toString(this.socketCliente.getLocalPort());
			this.servidorNomeHost = socketCliente.getLocalAddress().getHostName();
			
			this.arquivoFisico = null;
			this.saidaDoCliente = null;
		} catch(Exception e){
			this.fechar();
			throw e;			
		}
	}
	
//######################################################################################
	public void fechar(){
		if(this.inputVindoDoCliente!=null){
			try {
				this.inputVindoDoCliente.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.outputVindoDoCliente!=null){
			try {
				this.outputVindoDoCliente.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.socketCliente!=null){
			try {
				this.socketCliente.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.clienteInput !=null){
			try {
				this.clienteInput.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.clienteOutput!=null){
			try {
				this.clienteOutput.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.arquivoFisico!=null){
			try {
				this.arquivoFisico.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		if(this.saidaDoCliente!=null){
			try {
				this.saidaDoCliente.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		
		this.inputVindoDoCliente = null;
		this.outputVindoDoCliente = null;
		this.arquivoFisico = null;
		this.saidaDoCliente = null;
		this.clienteInput = null;
		this.clienteOutput = null;
		this.socketCliente = null;
		this.inicializado = false;
		this.executando = false;
		this.envioMensagem = false;
		this.thread = null;
		this.servidor.diminuiContMaxConexao();
	}
	
//######################################################################################
	@Override
	public void run() {
		while(this.executando == true){
			String mensagem;
			
			
			try {
				this.socketCliente.setSoTimeout(2500);
				
				
				//if(this.envioMensagem == true){
					mensagem = this.inputVindoDoCliente.readLine();
					this.comando = new Comando(mensagem);
					
					System.out.println("Mensagem recebida do cliente ["+this.clienteIpHost+":"+this.clientePortaHost+"]{"+this.clienteNomeHost+"}: "+mensagem);
					if(mensagem == null){
						System.out.println("Foi perdida a conex�o entre o servidor e o cliente.");
						System.out.println("A conex�o ser� fechada...");
						break;
					}else if("FIM".equals(mensagem)){
						this.outputVindoDoCliente.println("Servidor disse: Esta Conex�o Ser� Finalizada...");
						break;
					}else if(Propriedades._COMANDO_.toUpperCase().equals(comando.getComando())){
						if(comando.getArquivo().isEmpty()){
							this.outputVindoDoCliente.println("Servidor disse: Nome do arquivo nao pode ficar em branco!");
						}else{
							//this.outputVindoDoCliente.println("Enviando Arquivo!");
							//this.outputVindoDoCliente.println(comando.getArquivo()+" "+comando.getArquivo());
							new ServidorEnviarArquivo(this,comando.getArquivo()).start();
						}						
					}else{
						mensagem = "Servidor disse: Voc� digitou uma resposta n�o prevista pelo Servidor";
						this.outputVindoDoCliente.println(mensagem);
					}
				//}
			}catch(SocketTimeoutException e){
				//ignorar
			}catch(Exception e){
				System.out.println(e);
				System.out.println("Foi perdida a conex�o entre o servidor e o cliente.");
				System.out.println("A conex�o ser� fechada...");
				break;
			}
		}
		
		this.fechar();
		this.servidor.imprimirConexaoAtivas();
		System.out.println("Conex�o do Cliente "+this.clienteNomeHost+" foi finalizada.");

	}
	
//######################################################################################
	public void start(){
		   if(this.inicializado == false || this.executando == true){
			   return;
		   }
		   this.executando = true;
		   this.thread = new Thread(this);
		   this.thread.start();
	}
	
//######################################################################################
	public void stop() throws Exception{
		   this.executando = false;
		   this.servidor.diminuiContMaxConexao();
		   this.fechar();
		   
		   if(this.thread != null){
		 //faz a thread X(Servidor) esperar a thread Y(Atendente) morrer para seguir
			   this.thread.join();
		   }
		   
	}	
	//######################################################################################
	
	public void recebeMsg(String mensagem) {
		this.outputVindoDoCliente.println("\nServidor disse: "+mensagem);
		
	}
	//######################################################################################
	public void mandaMsg(String mensagem) {
		this.outputVindoDoCliente.println(mensagem);
		
	}
	//######################################################################################
	
	public boolean isRodando() {
		return executando;
	}
	//######################################################################################	
	
	public void EnviarArquivo(String nome){
		nome = nome.trim();
		LeitorDeArquivo leitor = new LeitorDeArquivo(Propriedades._PASTA_SERVIDOR_+nome);
				
		if(leitor.validaCaminhoArquivoOK() == true){
			System.out.println("------------------------------------------------------------------");
			System.out.println("Enviando arquivo para ["+this.clienteIpHost+":"+this.clientePortaHost+"] ...");
			System.out.println("------------------------------------------------------------------");
			File file =  leitor.getArquivo();
			
			saidaDoCliente = new BufferedOutputStream(this.clienteOutput);
			
			try {
				arquivoFisico = new FileInputStream(file);
				int totalByteLidos;
				byte[] bufferBytesLidos = new byte[1024];
				
				/*
				saidaDoCliente.flush();
				saidaDoCliente.write(Propriedades._ARQUIVO_ENCONTRADO_.getBytes(), 0, Propriedades._ARQUIVO_ENCONTRADO_.getBytes().length);
				saidaDoCliente.flush();
				saidaDoCliente.write(new String("\n ").getBytes(), 0, new String("\n ").getBytes().length);
				
				try {
				    Thread.sleep(5*000);
				} catch(InterruptedException ex) {
				    Thread.currentThread().interrupt();
				}
				
				*/
				
				while((totalByteLidos = arquivoFisico.read(bufferBytesLidos,0,1024)) != -1){
					saidaDoCliente.flush();
					saidaDoCliente.write(bufferBytesLidos, 0, totalByteLidos);
					saidaDoCliente.flush();
					//System.out.println(new String(bufferBytesLidos)+" "+totalByteLidos);
				}
				
				saidaDoCliente.flush();
				saidaDoCliente.write(new String(" ").getBytes(), 0, new String(" ").getBytes().length);
				
				System.out.println("Arquivo enviado com sucesso para ["+this.clienteIpHost+":"+this.clientePortaHost+"]");
				System.out.println("------------------------------------------------------------------");
			} catch (FileNotFoundException e) {		
				System.out.println("Arquivo "+nome+" nao foi encontrado");
			} catch (IOException e) {
				System.out.println("servidor: Ocorreu erro de I/O!!");
			}
		}else{
			this.outputVindoDoCliente.println("Arquivo N�o encontrado No Servidor!");
			System.out.println("A maquina["+this.clienteIpHost+":"+this.clientePortaHost+"] pediu um arquivo que nao foi encontrado!");
		}
		
		
		
	}  

	  
	  
	//######################################################################################

}