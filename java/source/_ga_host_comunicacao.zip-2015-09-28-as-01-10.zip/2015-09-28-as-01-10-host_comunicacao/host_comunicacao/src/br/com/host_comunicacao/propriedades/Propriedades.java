package br.com.host_comunicacao.propriedades;

public final class Propriedades {
	public static final String _COMANDO_ = "GET";
	public static final String _PASTA_PADRAO_DE_ARQUIVOS = "src/br/com/host_comunicacao/arquivos/";
	public static final String _PASTA_SERVIDOR_ = "src/br/com/host_comunicacao/arquivos/servidor/";
	public static final String _PASTA_CLIENTE_ = "src/br/com/host_comunicacao/arquivos/cliente/";
	public static final String _ARQUIVO_ENCONTRADO_ = "[[[ARQUIVO_ENCONTRADO]]]";
	
	
	
}
