package br.com.host_comunicacao.util;

public class Comando {
	private String comando;
	private String arquivo;
	
	public Comando(String str){
		str = str.trim();
		String [] vetString = str.split("\\s", 4);
		this.comando = vetString[0].trim().toUpperCase();
		System.out.println(vetString.length);
		
		if(vetString.length > 1){
			this.arquivo = vetString[1].trim().toLowerCase();
		}else{
			this.arquivo = "";
		}
	}
	//####################################################
		
	public String getComando(){
		return this.comando;
	}
	//####################################################
	
	public String getArquivo(){
		return this.arquivo;
	}
	//####################################################
	
	 public static void main(String[] args) {
		 Comando c = new Comando("ENVIAR    CARNE ASSADA NA CHURRASQUEIRA");
		 System.out.println("comand: "+c.getComando() +"\n arq: "+c.getArquivo());
		 
		 Comando c2 = new Comando("ENVIAR    ");
		 System.out.println("comand: "+c2.getComando() +"\n arq: "+c2.getArquivo());
	}
 
}
