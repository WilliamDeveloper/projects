package br.com.host_comunicacao.chat;

public class ClienteReceberArquivo implements Runnable {
	private Cliente cliente;
	private String nomeArquivo;
	private Thread threadCliente;
	
	public ClienteReceberArquivo(Cliente cliente, String nomeArquivo) {
		this.cliente = cliente;
		this.nomeArquivo = nomeArquivo;
	}
	
	public void start(){
		   this.threadCliente = new Thread(this);
		   this.threadCliente.start();
	}
	
	@Override
	public void run() {
		this.cliente.receberArquivo(this.nomeArquivo);
		this.cliente.desbloquearEnvioMensagem();
		this.cliente = null;
		this.nomeArquivo = null;
		this.threadCliente = null;
		
	}
}
