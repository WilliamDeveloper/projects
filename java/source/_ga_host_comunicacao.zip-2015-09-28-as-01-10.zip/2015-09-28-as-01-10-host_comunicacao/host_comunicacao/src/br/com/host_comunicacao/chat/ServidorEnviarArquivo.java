package br.com.host_comunicacao.chat;

import java.lang.reflect.Constructor;

public class ServidorEnviarArquivo implements Runnable {
	
	private InformaNovaMsgDoCliente informante;
	private String nomeArquivo;
	private Thread threadCliente;
	
	public ServidorEnviarArquivo(InformaNovaMsgDoCliente informante, String nomeArquivo) {
		this.informante = informante;
		this.nomeArquivo = nomeArquivo;
	}
	
	public void start(){
		   this.threadCliente = new Thread(this);
		   this.threadCliente.start();
	}
	
	@Override
	public void run() {
		this.informante.EnviarArquivo(this.nomeArquivo);
		this.informante.mandaMsg("\n");
		this.informante = null;
		this.nomeArquivo = null;
		this.threadCliente = null;		
	}

}
