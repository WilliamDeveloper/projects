package br.com.mvc.model;

public class ServerInfo {

    public String vNome;
    public String vIP;
    public String vPorta;
    public String vHashRangeStart;
    public String vHashRangeEnd;
    public String vStatus;
    
}
