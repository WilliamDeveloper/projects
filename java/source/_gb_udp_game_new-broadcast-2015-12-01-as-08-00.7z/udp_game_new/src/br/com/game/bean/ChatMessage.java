package br.com.game.bean;

import br.com.game.jogo.JogoDaVelha;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ChatMessage implements Serializable {

    private String name;
    private String text;
    private String nameReserved;
    private String nameSend;
    private String salaNew;
    private String salaAtual;
    private String salaQtdePLayers;
    private String statusJogador;
    private String minhaEscolhaXisBola;
    private String proximaJogadaXisBola;
    private String botaoPressionado;
    private String hostIp;
    private String hostPorta;
    private String hostData;
    private String hostBroadCast;
    private Set<String> setOnlines = new HashSet<String>();
    private Map<String, String> listaSala = new HashMap<String, String>();
    private Action action;
    

    public String getBotaoPressionado() {
        return botaoPressionado;
    }

    public void setBotaoPressionado(String botaoPressionado) {
        this.botaoPressionado = botaoPressionado;
    }

    public String getProximaJogadaXisBola() {
        return proximaJogadaXisBola;
    }

    public void setProximaJogadaXisBola(String proximaJogadaXisBola) {
        this.proximaJogadaXisBola = proximaJogadaXisBola;
    }

    public String getMinhaEscolhaXisBola() {
        return minhaEscolhaXisBola;
    }

    public void setMinhaEscolhaXisBola(String minhaEscolhaXisBola) {
        this.minhaEscolhaXisBola = minhaEscolhaXisBola;
    }

    public String getSalaQtdePLayers() {
        return salaQtdePLayers;
    }

    public void setSalaQtdePLayers(String salaQtdePLayers) {
        this.salaQtdePLayers = salaQtdePLayers;
    }

    public String getStatusJogador() {
        return statusJogador;
    }

    public void setStatusJogador(String statusJogador) {
        this.statusJogador = statusJogador;
    }

    public enum Action {

        CONNECT, DISCONECT,SEND_PRIVATE, SEND_ONE, SEN_ALL, USERS_ONLINE, NOVA_SALA, LISTAR_SALAS, ENTRAR_SALA, SAIR_SALA, NEXT_PLAY,YOU_LOSE
    }

    public Map<String, String> getListaSala() {
        return listaSala;
    }

    public void setListaSala(Map<String, String> listaSala) {
        this.listaSala = listaSala;
    }

    public String getNameSend() {
        return nameSend;
    }

    public void setNameSend(String nameSend) {
        this.nameSend = nameSend;
    }

    public String getSalaNew() {
        return salaNew;
    }

    public void setSalaNew(String salaNew) {
        this.salaNew = salaNew;
    }

    public String getSalaAtual() {
        return salaAtual;
    }

    public void setSalaAtual(String salaAtual) {
        this.salaAtual = salaAtual;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getNameReserved() {
        return nameReserved;
    }

    public void setNameReserved(String nameReserved) {
        this.nameReserved = nameReserved;
    }

    public Set<String> getSetOnlines() {
        return setOnlines;
    }

    public void setSetOnlines(Set<String> setOnlines) {
        this.setOnlines = setOnlines;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public String getHostIp() {
        return hostIp;
    }

    public void setHostIp(String hostIp) {
        this.hostIp = hostIp;
    }

    public String getHostPorta() {
        return hostPorta;
    }

    public void setHostPorta(String hostPort) {
        this.hostPorta = hostPort;
    }

    public String getHostData() {
        return hostData;
    }

    public void setHostData(String hostData) {
        this.hostData = hostData;
    }

    public String getHostBroadCast() {
        return hostBroadCast;
    }

    public void setHostBroadCast(String hostBroadCast) {
        this.hostBroadCast = hostBroadCast;
    }

}
