/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.exemplos;

import br.com.game.utilitarios.BroadCast;
import br.com.game.utilitarios.BroadCast;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 201232
 */
public class TesteSocket {
    public static void main(String [] args) throws IOException{
                     int PORT = 4000;
             byte[] buf = new byte[1000];
        
        System.out.println("TESTES DATAGRAM");
        DatagramSocket clientDatagramSocket;
        DatagramSocket servidorDatagramSocket;
        try {
                servidorDatagramSocket = new DatagramSocket(PORT);
               //servidorDatagramSocket.setReuseAddress(true);
                clientDatagramSocket = new DatagramSocket();               
               //clientDatagramSocket.setReuseAddress(true);
            
            //System.out.println("getReuseAddress-"+clientSocket.getInetAddress().isMulticastAddress());
            //System.out.println("getReuseAddress-"+clientSocket.getInetAddress().getCanonicalHostName());
            //System.out.println("getReuseAddress-"+clientSocket.getInetAddress().getHostAddress());
            //System.out.println("getReuseAddress-"+clientSocket.getInetAddress().getHostName());
            System.out.println("getInetAddress-"+clientDatagramSocket.getInetAddress());
            
            System.out.println("getReuseAddress-"+clientDatagramSocket.getReuseAddress());
            System.out.println("getSoTimeout-"+clientDatagramSocket.getSoTimeout());
            System.out.println("getSendBufferSize-"+clientDatagramSocket.getSendBufferSize());
            System.out.println("getReceiveBufferSize-"+clientDatagramSocket.getReceiveBufferSize());
            System.out.println("getRemoteSocketAddress-"+clientDatagramSocket.getRemoteSocketAddress());
            System.out.println("getPort-"+clientDatagramSocket.getPort());
            System.out.println("getInetAddress-"+clientDatagramSocket.getInetAddress());
            System.out.println("getLocalPort-"+clientDatagramSocket.getLocalPort());
            System.out.println("getLocalAddress-"+clientDatagramSocket.getLocalAddress());
            System.out.println("getChannel-"+clientDatagramSocket.getChannel());
            System.out.println("getBroadcast-"+clientDatagramSocket.getBroadcast());
            System.out.println("isBound-"+clientDatagramSocket.isBound());
            System.out.println("isConnected-"+clientDatagramSocket.isConnected());            
            System.out.println("isClosed-"+clientDatagramSocket.isClosed());
            buf = ("envio: ").getBytes();
            InetAddress address = InetAddress.getByName(BroadCast.getBroadCast());
            DatagramPacket out = new DatagramPacket(buf, buf.length, address, PORT);
            clientDatagramSocket.send(out);
            
            //recebimento

             DatagramPacket dgp = new DatagramPacket(buf, buf.length);
          
             servidorDatagramSocket.receive(dgp);
             System.out.println("dgp.getData()"+dgp.getData());
             System.out.println("dgp.getData().dadosVindos: "+new String(dgp.getData()));
             System.out.println("dgp.getAddress()"+dgp.getAddress());
             System.out.println("dgp.getPort()"+dgp.getPort());
             System.out.println("dgp.getLength()"+dgp.getLength());
             System.out.println("dgp.getSocketAddress()"+dgp.getSocketAddress());
             
             
             //envio
             buf = ("envio:2 ").getBytes();
             DatagramPacket out2 = new DatagramPacket(buf, buf.length, dgp.getAddress(), dgp.getPort());             
             servidorDatagramSocket.send(out2);
             
             clientDatagramSocket.receive(dgp);
             
             System.out.println(" clientSocket.receive(dgp);: "+new String(dgp.getData()));
             
             
             
             
             servidorDatagramSocket.close();    
            clientDatagramSocket.close();
        } catch (SocketException ex) {
            Logger.getLogger(TesteSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}
