/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.utilitarios;

import java.net.InetSocketAddress;
import java.net.Socket;

/**
 *
 * @author william
 */
public class ProximaPorta {

    public static String getProximaPorta() {
        int porta = 4446;
        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress("localhost", porta), 6000);
            socket.close();
            System.out.println(" - Porta " + porta + " está disponivel");
        } catch (Exception ex) {
            return "NAO";
        }
        return "SIM";
    }
    
    public static void main(String[] args) {
        System.out.println(ProximaPorta.getProximaPorta());
    }
}
