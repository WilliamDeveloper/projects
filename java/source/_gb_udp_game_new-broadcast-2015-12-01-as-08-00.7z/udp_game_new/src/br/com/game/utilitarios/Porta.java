/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.utilitarios;

import java.net.InetSocketAddress;
import java.net.Socket;

/**
 *
 * @author william
 */
public class Porta {

    public static void main(String[] args) {
        Porta.getPortasDisponiveis();
        System.out.println("\n\n");
        Porta.isOpen("192.168.2.103",139);
    }

    public static void getPortasDisponiveis() {
        int contador = 0;
        for (int porta = 1; porta <= 65535; porta++) {
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress("localhost", porta), 2000);
                socket.close();
                System.out.println((contador++)+" - Porta " + porta + " está disponivel");
            } catch (Exception ex) {
            }
        }
    }
    public static void isOpen(String ipHost, int porta) {      
            try {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress(ipHost, porta), 1000);
                socket.close();
                System.out.println("Porta " + porta + " está disponivel");
            } catch (Exception ex) {
                System.out.println("Porta " + porta + " não está disponivel");
            }        
    }
}
