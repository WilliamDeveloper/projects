/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.exemplos;

import br.com.game.constantes.ConstanteMulticast;
import br.com.game.utilitarios.BroadCast;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author william
 */
public class TesteMulticast {
        public static void main(String [] args) throws IOException{
                     int PORT = 4000;
             byte[] buf = new byte[1000];
        
            System.out.println("TESTES DATAGRAM");
            System.out.println(""+ConstanteMulticast._IP_MULTICAST_);
            System.out.println(""+ConstanteMulticast._PORTA_MULTICAST_); 
            System.out.println("InetAddress.getLocalHost()-"+InetAddress.getLocalHost());
            
            MulticastSocket serverMulticastSocket  = new MulticastSocket(ConstanteMulticast._PORTA_MULTICAST_);
            InetAddress grupoMulticast = InetAddress.getByName(ConstanteMulticast._IP_MULTICAST_);
            serverMulticastSocket.joinGroup(grupoMulticast);
            DatagramSocket clientDatagramSocket = null;
        
        try {
                
               
            clientDatagramSocket = new DatagramSocket();               
               
            System.out.println("getInetAddress-"+clientDatagramSocket.getInetAddress());
            
            System.out.println("getReuseAddress-"+clientDatagramSocket.getReuseAddress());
            System.out.println("getSoTimeout-"+clientDatagramSocket.getSoTimeout());
            System.out.println("getSendBufferSize-"+clientDatagramSocket.getSendBufferSize());
            System.out.println("getReceiveBufferSize-"+clientDatagramSocket.getReceiveBufferSize());
            System.out.println("getRemoteSocketAddress-"+clientDatagramSocket.getRemoteSocketAddress());
            System.out.println("getPort-"+clientDatagramSocket.getPort());
            System.out.println("getInetAddress-"+clientDatagramSocket.getInetAddress());
            System.out.println("getLocalPort-"+clientDatagramSocket.getLocalPort());
            System.out.println("getLocalAddress-"+clientDatagramSocket.getLocalAddress());
            System.out.println("getChannel-"+clientDatagramSocket.getChannel());
            System.out.println("getBroadcast-"+clientDatagramSocket.getBroadcast());
            System.out.println("isBound-"+clientDatagramSocket.isBound());
            System.out.println("isConnected-"+clientDatagramSocket.isConnected());            
            System.out.println("isClosed-"+clientDatagramSocket.isClosed());
            buf = ("envio: ").getBytes();
            //InetAddress address = InetAddress.getByName(BroadCast.getBroadCast());
            DatagramPacket out = new DatagramPacket(buf, buf.length, grupoMulticast, ConstanteMulticast._PORTA_MULTICAST_);
            clientDatagramSocket.send(out);
            
            //recebimento

             DatagramPacket dgp = new DatagramPacket(buf, buf.length);
          
             serverMulticastSocket.receive(dgp);
             System.out.println("serverMulticastSocket.getInterface()"+serverMulticastSocket.getInterface());
             System.out.println("serverMulticastSocket.getLocalAddress()"+serverMulticastSocket.getLocalAddress());
             System.out.println("serverMulticastSocket.getLocalPort()"+serverMulticastSocket.getLocalPort());
             System.out.println("serverMulticastSocket.getInetAddress()"+serverMulticastSocket.getInetAddress());
             
             
             System.out.println("dgp.getData()"+dgp.getData());
             System.out.println("dgp.getData().dadosVindos: "+new String(dgp.getData()));
             System.out.println("dgp.getAddress()"+dgp.getAddress());
             System.out.println("dgp.getPort()"+dgp.getPort());
             System.out.println("dgp.getLength()"+dgp.getLength());
             System.out.println("dgp.getSocketAddress()"+dgp.getSocketAddress());
             
             
             //envio
             buf = ("envio:2 ").getBytes();
             DatagramPacket out2 = new DatagramPacket(buf, buf.length, dgp.getAddress(), dgp.getPort());             
             serverMulticastSocket.send(out2);
             
             clientDatagramSocket.receive(dgp);
             
             System.out.println(" clientSocket.receive(dgp);: "+new String(dgp.getData()));
             
             
             
             
             serverMulticastSocket.close();    
            clientDatagramSocket.close();
        } catch (SocketException ex) {
            Logger.getLogger(br.com.game.exemplos.TesteSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}
