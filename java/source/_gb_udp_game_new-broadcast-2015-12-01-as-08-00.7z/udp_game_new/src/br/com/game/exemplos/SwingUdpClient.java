package br.com.game.exemplos;

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SwingUdpClient extends JFrame implements ActionListener {

    JTextField txtfield;
    JTextArea txtarea;
    byte[] receiveBytes, sendBytes;
    String senddata;
    DatagramSocket dataSocketClient, dataSocketServer;
    JButton button1;

    public static void main(String[] args) {
        SwingUdpClient obj = new SwingUdpClient();
    }

    public SwingUdpClient() {
        this.setSize(300, 300);
        this.setTitle("Client");
        this.setBackground(Color.black);
        txtfield = new JTextField();
        txtfield.setBackground(Color.white);
        txtfield.setForeground(Color.blue);
        this.add(txtfield, BorderLayout.NORTH);
        txtarea = new JTextArea();
        txtarea.setBackground(Color.black);
        txtarea.setForeground(Color.green);

        this.add(txtarea, BorderLayout.CENTER);
        button1 = new JButton("SEND");
        this.add(button1, BorderLayout.SOUTH);
        button1.addActionListener(this);
        this.setVisible(true);
        receiveBytes = new byte[1024];
        sendBytes = new byte[1024];
        //setDefaultCloseOperation(EXIT_ON_CLOSE);	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	//****************************************************************
        try {
            dataSocketClient = new DatagramSocket();
            dataSocketServer = new DatagramSocket(9998);
            while (true) {
                DatagramPacket datapack = new DatagramPacket(receiveBytes, receiveBytes.length);
                dataSocketServer.receive(datapack);
                String msg = new String(datapack.getData());
                //String value=display.getText();
                txtarea.append("\nServer:" + msg);
            }
        } catch (Exception e) {
        }

    }

	//*********************************************************************
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getActionCommand() == "SEND") {
                String message = txtfield.getText();
                sendBytes = message.getBytes();
                DatagramPacket sendDataPack = new DatagramPacket(sendBytes, sendBytes.length, InetAddress.getLocalHost(), 9999);
                dataSocketClient.send(sendDataPack);
                txtarea.append("\nMyself:" + message);
                txtfield.setText("");
            }
        } catch (Exception a) {
        }
    }

}
