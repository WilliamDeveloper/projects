/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.transfer;

import br.com.game.bean.ChatMessage;
import static br.com.game.utilitarios.BroadCast.getBroadCast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author william
 */
public class ConvertObject {

    public static byte[] serialize(Object obj) {
        if (obj == null) {
            return new byte[0];
        }
        try (ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
                ObjectOutputStream objectOut = new ObjectOutputStream(byteArrayOut)) {
            objectOut.writeObject(obj);
            return byteArrayOut.toByteArray();
        } catch (final IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    public static <T> T deserialize(byte[] objectBytes, Class<T> type) {
        if (objectBytes == null || objectBytes.length == 0) {
            return null;
        }

        try (ByteArrayInputStream byteArrayIn = new ByteArrayInputStream(objectBytes); ObjectInputStream objectIn = new ObjectInputStream(byteArrayIn)) {
            return (T) objectIn.readObject();
        } catch (final Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(final String[] args) {
        ChatMessage c = new ChatMessage();
        c.setText("texto");
        // serialize to the byte array
        byte[] objectBytes = ConvertObject.serialize(c);
        // deserialize from the byte array
        ChatMessage blogUserFromBytes = ConvertObject.deserialize(objectBytes, ChatMessage.class);
        System.out.println(blogUserFromBytes.getText().toUpperCase());

    }

}
