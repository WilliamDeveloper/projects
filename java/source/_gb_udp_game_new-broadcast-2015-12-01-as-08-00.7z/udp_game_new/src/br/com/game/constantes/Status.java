
package br.com.game.constantes;


public enum Status {
    CONECTADO , DESCONECTADO , DISPONIVEL, JOGANDO, INDISPONIVEL
}
