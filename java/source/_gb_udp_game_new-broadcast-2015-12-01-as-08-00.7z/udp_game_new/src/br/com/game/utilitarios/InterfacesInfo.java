/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.utilitarios;

import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author william
 */
public class InterfacesInfo {

    public static void main(String[] args) throws Exception {
        getInterfaces();
    }

    public static void getInterfaces() throws SocketException {
        Enumeration<NetworkInterface> interfacesDeRede = NetworkInterface.getNetworkInterfaces();
        while (interfacesDeRede.hasMoreElements()) {
            NetworkInterface ni = interfacesDeRede.nextElement();            

            List<InterfaceAddress> list = ni.getInterfaceAddresses();
            Iterator<InterfaceAddress> it = list.iterator();

            while (it.hasNext()) {
                InterfaceAddress ia = it.next();
                if (ia.getBroadcast() != null) {
                    System.out.println("\n Display Name = " + ni.getDisplayName());
                    
                    System.out.println(" Address = " + ia.getAddress());
                    System.out.println(" NetworkPrefixLength = " + ia.getNetworkPrefixLength());
                    System.out.println(" Broadcast = " + ia.getBroadcast().toString().substring(1));
                }
            }
        }
    }
}
