/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.transfer;

import br.com.game.bean.ChatMessage;
import br.com.game.constantes.ConstanteMulticast;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TransferServer {

    private MulticastSocket serverMultiCastSocket = null;
    private InetAddress grupoMulticast = null;

    public TransferServer(int porta) {
        try {

            this.serverMultiCastSocket = new MulticastSocket(porta);
            this.grupoMulticast = InetAddress.getByName(ConstanteMulticast._IP_MULTICAST_);
            this.serverMultiCastSocket.joinGroup(grupoMulticast);
        } catch (SocketException ex) {
            Logger.getLogger(TransferServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TransferServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sp_serverEnviarPacote(ChatMessage chatMessage) {
        try {
            InetAddress ipAddress = InetAddress.getByName(chatMessage.getHostIp());
            int porta = Integer.parseInt(chatMessage.getHostPorta());
            byte[] sendData = ConvertObject.serialize(chatMessage);
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ipAddress, porta);
            this.serverMultiCastSocket.send(sendPacket);
        } catch (UnknownHostException ex) {
            Logger.getLogger(TransferServer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TransferServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ChatMessage sf_serverReceberPacote() {
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        try {
            this.serverMultiCastSocket.receive(receivePacket);
        } catch (IOException ex) {
            Logger.getLogger(TransferServer.class.getName()).log(Level.SEVERE, null, ex);
        }

        ChatMessage chatMessage = ConvertObject.deserialize(receivePacket.getData(), ChatMessage.class);
        chatMessage.setHostIp(receivePacket.getAddress().getHostAddress());
        chatMessage.setHostPorta(String.valueOf(receivePacket.getPort()));
        return chatMessage;
    }
    
}