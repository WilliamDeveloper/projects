/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.service;

import br.com.game.bean.ChatMessage;
import br.com.game.constantes.ConstanteMulticast;
import br.com.game.transfer.TransferCliente;

public class ClienteService {

    private final TransferCliente transfer;

    public ClienteService() {
        this.transfer = new TransferCliente(ConstanteMulticast._PORTA_MULTICAST_);
    }

    public void connect(ChatMessage chatMessage) {
        chatMessage.setAction(ChatMessage.Action.CONNECT);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public void disconnect(ChatMessage chatMessage) {
        chatMessage.setAction(ChatMessage.Action.DISCONECT);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public void send(ChatMessage message) {
        this.transfer.sp_clienteEnviarPacote(message);
    }

    public void sendOne(ChatMessage chatMessage) {
        chatMessage.setAction(ChatMessage.Action.SEND_ONE);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public void sendAll(ChatMessage chatMessage) {
        chatMessage.setAction(ChatMessage.Action.SEN_ALL);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public void criandoSala(ChatMessage chatMessage) {
        chatMessage.setAction(ChatMessage.Action.NOVA_SALA);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public void listarSalas(ChatMessage message) {
        message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        message.setAction(ChatMessage.Action.LISTAR_SALAS);
        this.transfer.sp_clienteEnviarPacote(message);
    }

    public void usersOnline(ChatMessage chatMessage) {
        chatMessage.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        chatMessage.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        chatMessage.setAction(ChatMessage.Action.USERS_ONLINE);
        this.transfer.sp_clienteEnviarPacote(chatMessage);
    }

    public ChatMessage sf_clienteReceberPacote() {
        return this.transfer.sf_clienteReceberPacote();
    }

    public void sairSala(ChatMessage message) {
        message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        message.setAction(ChatMessage.Action.SAIR_SALA);
        this.transfer.sp_clienteEnviarPacote(message);
    }

    public void entrarSala(ChatMessage message) {
        message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        message.setAction(ChatMessage.Action.ENTRAR_SALA);
        this.transfer.sp_clienteEnviarPacote(message);
    }

     public void nextPlay(ChatMessage message) {
        message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        message.setAction(ChatMessage.Action.NEXT_PLAY);
        this.transfer.sp_clienteEnviarPacote(message);
    }

    public void youLose(ChatMessage message) {
        message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
        message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        message.setAction(ChatMessage.Action.YOU_LOSE);
        this.transfer.sp_clienteEnviarPacote(message);
    }
}