/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.constantes;

/**
 *
 * @author william
 */
public class ConstanteMulticast {
    public static String _IP_MULTICAST_ = "230.0.0.1";
    public static int _PORTA_MULTICAST_ = 5556;
    
    
}
