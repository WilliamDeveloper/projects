package br.com.game.jogo;

import java.io.Serializable;

/**
 *
 * @author william
 */
public class JogoDaVelha implements Serializable {

    public static final String BOLA = "O";
    public static final String XIS = "X";

    String[] jogadas = new String[10];

    int[][] estadoFinal = new int[][]{
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9},
        {1, 4, 7},
        {2, 5, 8},
        {3, 6, 9},
        {1, 5, 9},
        {3, 5, 7},};

    public JogoDaVelha() {
        for (int i = 0; i < jogadas.length; i++) {
            jogadas[i] = "";
        }
    }

    public boolean isFim() {
        for (int x = 0; x <= 7; ++x) {
            String s1 = jogadas[estadoFinal[x][0]];
            String s2 = jogadas[estadoFinal[x][1]];
            String s3 = jogadas[estadoFinal[x][2]];

            if (s1.equals(s2) && s2.equals(s3) && !(s1.equals("") && s2.equals(""))) {

                return true;
            }
        }
        return false;
    }

    public String sequenciaGanhadora() {
        for (int x = 0; x <= 7; ++x) {
            String s1 = jogadas[estadoFinal[x][0]];
            String s2 = jogadas[estadoFinal[x][1]];
            String s3 = jogadas[estadoFinal[x][2]];

            if (s1.equals(s2) && s2.equals(s3) && !(s1.equals("") && s2.equals(""))) {

                return "{" + estadoFinal[x][0] + ", " + estadoFinal[x][1] + ", " + estadoFinal[x][2] + "}";
            }
        }
        return "";
    }

    public String getJogada(int index) {
        return jogadas[index];
    }

    public void setJogada(int index, String jogada) {
        this.jogadas[index] = jogada;
    }

    public static void main(String[] args) {
        JogoDaVelha j = new JogoDaVelha();
        j.setJogada(1, JogoDaVelha.XIS);
        j.setJogada(2, JogoDaVelha.XIS);
        j.setJogada(3, JogoDaVelha.XIS);
        System.out.println(j.isFim());
        System.out.println(j.sequenciaGanhadora());
    }

}
