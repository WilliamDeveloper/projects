package br.com.game.service;

import br.com.game.bean.ChatMessage;
import br.com.game.bean.ChatMessage.Action;
import br.com.game.constantes.ConstanteMulticast;
import br.com.game.constantes.Status;
import br.com.game.transfer.TransferServer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author william
 */
public class ServidorService {

    private Map<String, ChatMessage> mapOnlines = new HashMap<String, ChatMessage>();
    private Map<String, String> listaSala = new HashMap<String, String>();
    private int porta;
    private TransferServer transfer;
    private Thread thread;

    public ServidorService() {

        System.out.println("Servidor On");
        ChatMessage chatMessage = new ChatMessage();
        chatMessage.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
        this.transfer = new TransferServer(ConstanteMulticast._PORTA_MULTICAST_);
        this.thread = new Thread(new ListenerSocket());
        this.thread.start();
        System.out.println("somente a thread segura isso");
    }

    private class ListenerSocket implements Runnable {

        @Override
        public void run() {
            ChatMessage message = null;
            System.out.println("SERVER-RUN-START");//teste
            while ((message = transfer.sf_serverReceberPacote()) != null) {
                //log
                System.out.println("\nRServer::acao: " + message.getAction() + " user: " + message.getName() + " reserved: " + message.getNameReserved() + " text: " + message.getText() + " onlines: " + message.getSetOnlines() + " sala " + message.getSalaAtual() + " qtd " + message.getSalaQtdePLayers() + " minha: " + message.getMinhaEscolhaXisBola() + " proxJogada " + message.getProximaJogadaXisBola() + " botaoPressionado " + message.getBotaoPressionado());

                Action action = message.getAction();
                if (action.equals((Action.CONNECT))) {
                    boolean isConnect = connect(message);
                    if (isConnect) {
                        System.out.println("CADASTRANDO!-> no servidor");//teste
                        mapOnlines.put(message.getName(), message);
                        System.out.println(message.getName() + " - " + message.getNameReserved() + " - " + message.getHostIp() + " - " + message.getHostPorta() + ". " + message.getAction());//teste

                        transfer.sp_serverEnviarPacote(message);

                    }
                } else if (action.equals((Action.DISCONECT))) {
                    disconnect(message);
                    SendOnlines();
                    message.setAction(Action.DISCONECT);
                    send(message);
                    //return;
                } else if (action.equals((Action.SEND_ONE))) {
                    sendOne(message);
                } else if (action.equals((Action.SEND_PRIVATE))) {
                    sendOne(message);
                }else if (action.equals((Action.SEN_ALL))) {
                    sendAll(message);
                } else if (action.equals((Action.USERS_ONLINE))) {
                    System.out.println("SendOnlines");
                    SendOnlines();
                } else if (action.equals((Action.NOVA_SALA))) {
                    System.out.println("nova_sala: " + message.getSalaNew());
                    listaSala.put(message.getSalaNew(), "1");
                    mapOnlines.get(message.getName()).setStatusJogador(message.getStatusJogador());
                    mapOnlines.get(message.getName()).setSalaAtual(message.getSalaNew());
                    
                    System.out.println("modificado: " + mapOnlines.get(message.getName()).getStatusJogador());
                    //transfer.sp_serverEnviarPacote(message);
                    SendOnlines();
                } else if (action.equals((Action.LISTAR_SALAS))) {
                    //message.setListaSala(listaSala);
                    //transfer.sp_serverEnviarPacote(message);
                    SendListaSala();
                } else if (action.equals((Action.SAIR_SALA))) {
                    if (listaSala.get(message.getSalaAtual()).equals("1")) {
                        listaSala.remove(message.getSalaAtual());
                        mapOnlines.get(message.getName()).setSalaAtual("");
                        
                    } else {
                        listaSala.put(message.getSalaAtual(), "1");
                        

                    }
                    mapOnlines.get(message.getName()).setStatusJogador(message.getStatusJogador());
                    mapOnlines.get(message.getName()).setSalaAtual("");
                    
                    SendOnlines();
                } else if (action.equals((Action.ENTRAR_SALA))) {
                    String nomeSala = message.getSalaAtual();
                    int qtdPlayers = 0;
                    ChatMessage player1 = null;

                    for (Map.Entry<String, String> kv : listaSala.entrySet()) {
                        if (kv.getKey().equals(nomeSala)) {
                            qtdPlayers = Integer.valueOf(kv.getValue());                            
                            break;
                        }
                    }

                    if (qtdPlayers == 1) {                        
                        mapOnlines.get(message.getName()).setSalaAtual(message.getSalaAtual());
                        mapOnlines.get(message.getName()).setStatusJogador(Status.JOGANDO.toString());
                        listaSala.put(nomeSala, "2");
                        SendOnlines();
                    }
                } else if (action.equals((Action.NEXT_PLAY))) {
                    ChatMessage outroPlayer = null;
                    for (Map.Entry<String, ChatMessage> kv : mapOnlines.entrySet()) {
                        if (!kv.getKey().equals(message.getName()) && kv.getValue().getSalaAtual().equals(message.getSalaAtual())) {
                            outroPlayer = kv.getValue();
                            outroPlayer.setAction(Action.NEXT_PLAY);
                            outroPlayer.setMinhaEscolhaXisBola(message.getProximaJogadaXisBola());
                            outroPlayer.setProximaJogadaXisBola(message.getMinhaEscolhaXisBola());
                            outroPlayer.setBotaoPressionado(message.getBotaoPressionado());
                            outroPlayer.setNameReserved(outroPlayer.getName());
                                                        
                            sendOne(outroPlayer);
                            break;
                        }
                    }
                    System.out.println(":::"+message.getBotaoPressionado());

                }else if (action.equals((Action.YOU_LOSE))) {
                    ChatMessage outroPlayer = null;
                    for (Map.Entry<String, ChatMessage> kv : mapOnlines.entrySet()) {
                        if (!kv.getKey().equals(message.getName()) && kv.getValue().getSalaAtual().equals(message.getSalaAtual())) {
                            outroPlayer = kv.getValue();
                            outroPlayer.setAction(Action.YOU_LOSE);
                            outroPlayer.setMinhaEscolhaXisBola(message.getProximaJogadaXisBola());
                            outroPlayer.setProximaJogadaXisBola(message.getMinhaEscolhaXisBola());
                            outroPlayer.setBotaoPressionado(message.getBotaoPressionado());
                            outroPlayer.setNameReserved(outroPlayer.getName());
                            outroPlayer.setText(message.getText());
                                                        
                            sendOne(outroPlayer);
                            break;
                        }
                    }
                }
                mostrarOnline();//teste
            }
            System.out.println("SERVER-RUN-STOP");//teste
        }
    }

    private boolean connect(ChatMessage message) {
        if (this.mapOnlines.size() == 0) {
            message.setText("YES");
            //teste
            send(message);
            return true;
        }

        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            if (kv.getKey().equals(message.getName())) {
                message.setText("NO");
                //teste
                send(message);
                return false;
            } else {
                message.setText("YES");
                //teste
                send(message);
                return true;
            }
        }

        return false;
    }

    private void disconnect(ChatMessage message) {
        mapOnlines.remove(message.getName());

        message.setText(" até logo");

        sendAll(message);
        System.out.println("User " + message.getName() + " sai da sala");
    }

    private void send(ChatMessage chatMessage) {
        this.transfer.sp_serverEnviarPacote(chatMessage);
    }

    private void sendOne(ChatMessage message) {
        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            if (kv.getKey().equals(message.getNameReserved())) {
                ChatMessage chat = kv.getValue();
                chat.setText(message.getText());
                chat.setAction(message.getAction());
                chat.setNameSend(message.getName());//teste
                System.out.println("serverName " + chat.getName());
                this.transfer.sp_serverEnviarPacote(chat);
            }
        }
    }

    private void sendAll(ChatMessage message) {
        message.setAction(Action.SEND_ONE);
        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            if (!kv.getKey().equals(message.getName())) {

                System.out.println("user: " + message.getName() + " message: " + message.getText());
                ChatMessage chat = kv.getValue();
                chat.setText(message.getText());
                chat.setAction(message.getAction());
                chat.setNameSend(message.getName());//teste
                this.transfer.sp_serverEnviarPacote(chat);
            }
        }
    }

    public void mostrarOnline() {
        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            System.out.println("chave: " + kv.getKey() + " nome: " + kv.getValue().getName());
        }
        for (Map.Entry<String, String> kv : this.listaSala.entrySet()) {
            System.out.println("sala: " + kv.getKey() + " qtd: " + kv.getValue());
        }
    }

    private void SendOnlines() {
        Set<String> setNames = new HashSet<String>();
        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            setNames.add(kv.getKey() + "-" + kv.getValue().getStatusJogador());
        }

        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            //System.out.println("name"+message.getName());
            ChatMessage chat = kv.getValue();
            chat.setAction(Action.USERS_ONLINE);
            chat.setSetOnlines(setNames);
            this.transfer.sp_serverEnviarPacote(chat);
        }
    }

    private void SendListaSala() {
        for (Map.Entry<String, ChatMessage> kv : this.mapOnlines.entrySet()) {
            //System.out.println("name"+message.getName());
            ChatMessage chat = kv.getValue();
            chat.setAction(Action.LISTAR_SALAS);
            chat.setListaSala(listaSala);
            this.transfer.sp_serverEnviarPacote(chat);
        }
    }

}
