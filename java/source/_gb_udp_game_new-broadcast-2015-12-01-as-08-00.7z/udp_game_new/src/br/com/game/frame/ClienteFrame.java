package br.com.game.frame;

import br.com.game.bean.ChatMessage;
import br.com.game.bean.ChatMessage.Action;
import br.com.game.constantes.ConstanteMulticast;
import br.com.game.constantes.Status;
import br.com.game.jogo.JogoDaVelha;
import br.com.game.service.ClienteService;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Map;
import java.util.Set;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class ClienteFrame extends javax.swing.JFrame {

    private ChatMessage message;
    private ClienteService service;
    private JogoDaVelha jogoDaVelha;

    public ClienteFrame() {
        initComponents();
        this.btnStatus.setText(Status.DESCONECTADO.toString());
        this.message = new ChatMessage();

        //txtBroadCast.setText(BroadCast.getBroadCast());
        txtMultiCastIpGroup.setText(ConstanteMulticast._IP_MULTICAST_);
        txtMultiCastPorta.setText(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (btnStatus.getText().equals(Status.CONECTADO.toString())) {
                    service.disconnect(message);
                    disconnected();
                }
            }
        });
        this.txtSalaAtual.setText("");
        this.btnStatusJogador.setText(Status.INDISPONIVEL.toString());
    }

    private void habilitaRadioXisBola(boolean b) {
        this.rbBola.setEnabled(b);
        this.rbXis.setEnabled(b);
    }

    private void habilitarJogo(boolean b) {
        this.habilitaRadioXisBola(b);
        this.btn01.setEnabled(b);
        this.btn02.setEnabled(b);
        this.btn03.setEnabled(b);
        this.btn04.setEnabled(b);
        this.btn05.setEnabled(b);
        this.btn06.setEnabled(b);
        this.btn07.setEnabled(b);
        this.btn08.setEnabled(b);
        this.btn09.setEnabled(b);

    }

    private void limparJogo() {
        this.btn01.setText("");
        this.btn02.setText("");
        this.btn03.setText("");
        this.btn04.setText("");
        this.btn05.setText("");
        this.btn06.setText("");
        this.btn07.setText("");
        this.btn08.setText("");
        this.btn09.setText("");
        this.lbmensagem.setText("");
        this.btn01.setForeground(Color.BLACK);
        this.btn02.setForeground(Color.BLACK);
        this.btn03.setForeground(Color.BLACK);
        this.btn04.setForeground(Color.BLACK);
        this.btn05.setForeground(Color.BLACK);
        this.btn06.setForeground(Color.BLACK);
        this.btn07.setForeground(Color.BLACK);
        this.btn08.setForeground(Color.BLACK);
        this.btn09.setForeground(Color.BLACK);
        this.lbmensagem.setForeground(Color.BLACK);
        rbXis.setSelected(false);
        rbBola.setSelected(false);
    }

    private void sairDoJogo() {
        this.btnSalaCriar.setEnabled(true);
        this.btnSalaSair.setEnabled(false);
        this.btnJogoSair.setEnabled(false);
        this.message.setStatusJogador(Status.DISPONIVEL.toString());
        this.btnStatusJogador.setText(message.getStatusJogador());
        this.txtSalaAtual.setText("");
        System.out.println("SAINDO-DA-SALA: " + this.message.getSalaAtual());
        this.service.sairSala(this.message);
        this.message.setSalaAtual("");
        this.habilitarJogo(false);
        this.limparJogo();
    }

    private String getMinhaEscolha() {
        if (this.rbBola.isSelected()) {
            this.habilitaRadioXisBola(false);
            return JogoDaVelha.BOLA;
        } else if (this.rbXis.isSelected()) {
            this.habilitaRadioXisBola(false);
            return JogoDaVelha.XIS;
        }

        System.out.println("Selecione Xis ou Bola");
        return "Selecione Xis ou Bola";
    }

    private void setJogadaXisBola(JButton btn, String botaoPressionado) {

        String tmp = this.getMinhaEscolha();
        System.out.println("botao " + botaoPressionado + " tmp " + tmp);
        if (tmp.equals(JogoDaVelha.BOLA) || tmp.equals(JogoDaVelha.XIS)) {
            this.message.setMinhaEscolhaXisBola(tmp);
            this.message.setProximaJogadaXisBola(tmp.equals(JogoDaVelha.BOLA) ? JogoDaVelha.XIS : JogoDaVelha.BOLA);
            this.message.setBotaoPressionado(botaoPressionado);
            btn.setText(message.getMinhaEscolhaXisBola());
            btn.setEnabled(false);
            this.habilitaJogadaRestante(false);
            jogoDaVelha.setJogada(Integer.valueOf(botaoPressionado), tmp);

            if (jogoDaVelha.isFim()) {
                lbmensagem.setForeground(Color.RED);
                lbmensagem.setText("Voce Ganhou!");
                message.setText("Você Perdeu!");
                this.service.youLose(message);
                this.pintarBotoesVermelho();
            } else {
                this.service.nextPlay(message);
            }
        }
    }

    private void pintarBotoesVermelho() {
        String bt01 = this.btn01.getText();
        String bt02 = this.btn02.getText();
        String bt03 = this.btn03.getText();
        String bt04 = this.btn04.getText();
        String bt05 = this.btn05.getText();
        String bt06 = this.btn06.getText();
        String bt07 = this.btn07.getText();
        String bt08 = this.btn08.getText();
        String bt09 = this.btn09.getText();

        if (bt01.equals(bt02) && bt02.equals(bt03)) {
            this.btn01.setForeground(Color.red);
            this.btn02.setForeground(Color.red);
            this.btn03.setForeground(Color.red);
        } else if (bt04.equals(bt05) && bt05.equals(bt06)) {
            this.btn04.setForeground(Color.red);
            this.btn05.setForeground(Color.red);
            this.btn06.setForeground(Color.red);
        } else if (bt07.equals(bt08) && bt08.equals(bt09)) {
            this.btn07.setForeground(Color.red);
            this.btn08.setForeground(Color.red);
            this.btn09.setForeground(Color.red);
        } else if (bt01.equals(bt04) && bt04.equals(bt07)) {
            this.btn01.setForeground(Color.red);
            this.btn04.setForeground(Color.red);
            this.btn07.setForeground(Color.red);
        } else if (bt02.equals(bt05) && bt05.equals(bt08)) {
            this.btn02.setForeground(Color.red);
            this.btn05.setForeground(Color.red);
            this.btn08.setForeground(Color.red);
        } else if (bt03.equals(bt06) && bt06.equals(bt09)) {
            this.btn03.setForeground(Color.red);
            this.btn06.setForeground(Color.red);
            this.btn09.setForeground(Color.red);
        } else if (bt01.equals(bt05) && bt05.equals(bt09)) {
            this.btn01.setForeground(Color.red);
            this.btn05.setForeground(Color.red);
            this.btn09.setForeground(Color.red);
        } else if (bt03.equals(bt05) && bt05.equals(bt07)) {
            this.btn03.setForeground(Color.red);
            this.btn05.setForeground(Color.red);
            this.btn07.setForeground(Color.red);
        }
    }

    private void habilitaJogadaRestante(boolean b) {
        if (this.btn01.getText().isEmpty()) {
            this.btn01.setEnabled(b);
        }
        if (this.btn02.getText().isEmpty()) {
            this.btn02.setEnabled(b);
        }

        if (this.btn03.getText().isEmpty()) {
            this.btn03.setEnabled(b);
        }
        if (this.btn04.getText().isEmpty()) {
            this.btn04.setEnabled(b);
        }
        if (this.btn05.getText().isEmpty()) {
            this.btn05.setEnabled(b);
        }
        if (this.btn06.getText().isEmpty()) {
            this.btn06.setEnabled(b);
        }
        if (this.btn07.getText().isEmpty()) {
            this.btn07.setEnabled(b);
        }
        if (this.btn08.getText().isEmpty()) {
            this.btn08.setEnabled(b);
        }
        if (this.btn09.getText().isEmpty()) {
            this.btn09.setEnabled(b);
        }
    }

    private class ListenerSocket implements Runnable {

        @Override
        public void run() {
            ChatMessage message = null;
            System.out.println("CLIENT-RUN-START");//teste
            while ((message = service.sf_clienteReceberPacote()) != null) {
                ChatMessage.Action action = message.getAction();
                //log
                System.out.println("\nRCliente:::acao: " + message.getAction() + " user: " + message.getName() + " reserved: " + message.getNameReserved() + " text: " + message.getText() + " onlines: " + message.getSetOnlines() + " ip: " + message.getHostIp() + " porta " + message.getHostPorta() + " send " + message.getNameSend() + " sala " + message.getSalaAtual() + " qtd " + message.getSalaQtdePLayers() + " minha: " + message.getMinhaEscolhaXisBola() + " proxJogada " + message.getProximaJogadaXisBola() + " botaoPressionado " + message.getBotaoPressionado());

                if (action.equals((ChatMessage.Action.CONNECT))) {
                    System.out.println("CLIENT-CONECTADO-> " + message.getName());//teste
                    connected(message);
                    service.usersOnline(message);
                } else if (action.equals((ChatMessage.Action.DISCONECT))) {
                    disconnected();
                    break;//teste
                } else if (action.equals((ChatMessage.Action.SEND_ONE))) {
                    receive(message);
                } else if (action.equals((ChatMessage.Action.SEND_PRIVATE))) {
                    receive(message);
                } else if (action.equals((ChatMessage.Action.USERS_ONLINE))) {
                    usersOnline(message);
                    service.listarSalas(message);
                } else if (action.equals((Action.NOVA_SALA))) {
                    service.listarSalas(message);
                } else if (action.equals((Action.LISTAR_SALAS))) {
                    listaDeSalas(message);
                } else if (action.equals((Action.NEXT_PLAY))) {
                    lbmensagem.setText("");
                    habilitaJogadaRestante(true);
                    this.recebeJogadaAnterior(message);

                } else if (action.equals((Action.YOU_LOSE))) {
                    this.recebeJogadaAnterior(message);
                    lbmensagem.setText(message.getText());
                    lbmensagem.setForeground(Color.RED);
                    pintarBotoesVermelho();
                }
            }
            System.out.println("CLIENT-RUN-STOP");//teste
        }

        private void selectRadioButon(String minhaEscolhaXisBola) {
            switch (minhaEscolhaXisBola) {
                case JogoDaVelha.BOLA:
                    rbBola.setSelected(true);
                    rbBola.setEnabled(false);
                    break;
                case JogoDaVelha.XIS:
                    rbXis.setSelected(true);
                    rbXis.setEnabled(false);
                    break;
                default:
            }
        }

        private void recebeJogadaAnterior(ChatMessage message) {
            String botaoPressionado = message.getBotaoPressionado();
            switch (botaoPressionado) {
                case "1":
                    jogoDaVelha.setJogada(1, botaoPressionado);
                    btn01.setText(message.getProximaJogadaXisBola());
                    btn01.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "2":
                    jogoDaVelha.setJogada(2, botaoPressionado);
                    btn02.setText(message.getProximaJogadaXisBola());
                    btn02.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "3":
                    jogoDaVelha.setJogada(3, botaoPressionado);
                    btn03.setText(message.getProximaJogadaXisBola());
                    btn03.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "4":
                    jogoDaVelha.setJogada(4, botaoPressionado);
                    btn04.setText(message.getProximaJogadaXisBola());
                    btn04.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "5":
                    jogoDaVelha.setJogada(5, botaoPressionado);
                    btn05.setText(message.getProximaJogadaXisBola());
                    btn05.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "6":
                    jogoDaVelha.setJogada(6, botaoPressionado);
                    btn06.setText(message.getProximaJogadaXisBola());
                    btn06.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "7":
                    jogoDaVelha.setJogada(7, botaoPressionado);
                    btn07.setText(message.getProximaJogadaXisBola());
                    btn07.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "8":
                    jogoDaVelha.setJogada(8, botaoPressionado);
                    btn08.setText(message.getProximaJogadaXisBola());
                    btn08.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                case "9":
                    jogoDaVelha.setJogada(9, botaoPressionado);
                    btn09.setText(message.getProximaJogadaXisBola());
                    btn09.setEnabled(false);
                    this.selectRadioButon(message.getMinhaEscolhaXisBola());
                    break;
                default:

            }

        }
    }

    private void connected(ChatMessage message) {
        if (message.equals("NO")) {
            this.txtName.setText("");
            JOptionPane.showMessageDialog(this, "Conexao nao realizada!\nTente novamente com um novo nome.");
            return;
        }
        this.message = message;
        habilitarCampos(true);
        limparJogo();
        JOptionPane.showMessageDialog(this, "Conexao realizada com sucesso! " + message.getName());
        this.btnStatus.setText(Status.CONECTADO.toString());
    }

    private void disconnected() {
        habilitarCampos(false);
        this.txtAreaReceive.setText("");
        this.txtAreaSend.setText("");
        this.txtAreaPrivado.setText("");
        this.btnStatus.setText(Status.DESCONECTADO.toString());
        this.listOnlines.setListData(new Object[0]);
        this.listSalas.setListData(new Object[0]);
        JOptionPane.showMessageDialog(this, "Voce saiu do chat!");

    }

    private void habilitarCampos(boolean boleano) {
        this.btnConectar.setEnabled(!boleano);
        this.txtName.setEditable(!boleano);
        this.txtMultiCastPorta.setEnabled(!boleano);
        this.txtSalaNome.setEnabled(boleano);
        this.btnSalaCriar.setEnabled(boleano);
        this.btnSair.setEnabled(boleano);
        this.txtAreaSend.setEnabled(boleano);
        this.txtAreaReceive.setEnabled(boleano);
        this.txtAreaPrivado.setEnabled(boleano);
        this.btnEnviar.setEnabled(boleano);
        this.btnLimpar.setEnabled(boleano);
    }

    private void receive(ChatMessage message) {
        if (message.getAction().equals(Action.SEND_ONE)) {
            this.txtAreaReceive.append(message.getNameSend() + " diz: " + message.getText() + "\n");
        } else {
            this.txtAreaPrivado.append(message.getNameSend() + " diz: " + message.getText() + "\n");
        }
    }

    private void usersOnline(ChatMessage message) {
        System.out.println("usersOnline->" + message.getSetOnlines().toString());
        Set<String> names = message.getSetOnlines();
        names.remove((String) message.getName() + "-" + Status.DISPONIVEL.toString());
        names.remove((String) message.getName() + "-" + Status.JOGANDO.toString());

        String[] array = (String[]) names.toArray(new String[names.size()]);

        this.listOnlines.setListData(array);
        this.listOnlines.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.listOnlines.setLayoutOrientation(JList.VERTICAL);

    }

    private void listaDeSalas(ChatMessage message) {
        System.out.println("listaDeSalas->" + message.getListaSala().toString());
        String[] array = new String[message.getListaSala().size()];
        Map<String, String> listaSalas = message.getListaSala();
        int i = 0;
        for (Map.Entry<String, String> kv : listaSalas.entrySet()) {
            array[i++] = "[" + kv.getValue() + "/2]-" + kv.getKey();
        }

        this.listSalas.setListData(array);
        this.listSalas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.listSalas.setLayoutOrientation(JList.VERTICAL);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        groupButton = new javax.swing.ButtonGroup();
        jPanel8 = new javax.swing.JPanel();
        btn01 = new javax.swing.JButton();
        btn02 = new javax.swing.JButton();
        btn04 = new javax.swing.JButton();
        btn05 = new javax.swing.JButton();
        btn06 = new javax.swing.JButton();
        btn07 = new javax.swing.JButton();
        btn08 = new javax.swing.JButton();
        btn09 = new javax.swing.JButton();
        btn03 = new javax.swing.JButton();
        rbXis = new javax.swing.JRadioButton();
        rbBola = new javax.swing.JRadioButton();
        lbmensagem = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnConectar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        txtName = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        txtSalaNome = new javax.swing.JTextField();
        btnSalaCriar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listSalas = new javax.swing.JList();
        btnSalaEntrar = new javax.swing.JButton();
        btnSalaSair = new javax.swing.JButton();
        btnStatus = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listOnlines = new javax.swing.JList();
        jPanel11 = new javax.swing.JPanel();
        txtMultiCastIpGroup = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtMultiCastPorta = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtAreaPrivado = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaReceive = new javax.swing.JTextArea();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAreaSend = new javax.swing.JTextArea();
        btnLimpar = new javax.swing.JButton();
        btnEnviar = new javax.swing.JButton();
        btnStatusJogador = new javax.swing.JButton();
        lbSalaNome = new javax.swing.JLabel();
        btnJogoSair = new javax.swing.JButton();
        txtSalaAtual = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("UDP - COMUNICADOR");
        setSize(new java.awt.Dimension(900, 700));

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Jogo Velha"));
        jPanel8.setEnabled(false);

        btn01.setText("X");
        btn01.setEnabled(false);
        btn01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn01ActionPerformed(evt);
            }
        });

        btn02.setText("X");
        btn02.setEnabled(false);
        btn02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn02ActionPerformed(evt);
            }
        });

        btn04.setText("X");
        btn04.setEnabled(false);
        btn04.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn04ActionPerformed(evt);
            }
        });

        btn05.setText("X");
        btn05.setEnabled(false);
        btn05.setMaximumSize(new java.awt.Dimension(40, 25));
        btn05.setMinimumSize(new java.awt.Dimension(40, 25));
        btn05.setPreferredSize(new java.awt.Dimension(40, 25));
        btn05.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn05ActionPerformed(evt);
            }
        });

        btn06.setText("X");
        btn06.setEnabled(false);
        btn06.setMaximumSize(new java.awt.Dimension(40, 25));
        btn06.setMinimumSize(new java.awt.Dimension(40, 25));
        btn06.setPreferredSize(new java.awt.Dimension(40, 25));
        btn06.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn06ActionPerformed(evt);
            }
        });

        btn07.setText("X");
        btn07.setEnabled(false);
        btn07.setMaximumSize(new java.awt.Dimension(40, 25));
        btn07.setMinimumSize(new java.awt.Dimension(40, 25));
        btn07.setPreferredSize(new java.awt.Dimension(40, 25));
        btn07.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn07ActionPerformed(evt);
            }
        });

        btn08.setText("X");
        btn08.setEnabled(false);
        btn08.setMaximumSize(new java.awt.Dimension(40, 25));
        btn08.setMinimumSize(new java.awt.Dimension(40, 25));
        btn08.setPreferredSize(new java.awt.Dimension(40, 25));
        btn08.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn08ActionPerformed(evt);
            }
        });

        btn09.setText("X");
        btn09.setEnabled(false);
        btn09.setMaximumSize(new java.awt.Dimension(40, 25));
        btn09.setMinimumSize(new java.awt.Dimension(40, 25));
        btn09.setPreferredSize(new java.awt.Dimension(40, 25));
        btn09.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn09ActionPerformed(evt);
            }
        });

        btn03.setText("X");
        btn03.setEnabled(false);
        btn03.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn03ActionPerformed(evt);
            }
        });

        groupButton.add(rbXis);
        rbXis.setText("X");
        rbXis.setEnabled(false);
        rbXis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbXisActionPerformed(evt);
            }
        });

        groupButton.add(rbBola);
        rbBola.setText("O");
        rbBola.setEnabled(false);
        rbBola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbBolaActionPerformed(evt);
            }
        });

        lbmensagem.setText("Aguardando Jogadores");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbmensagem))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(btn07, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn08, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn09, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btn01, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn04, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(btn05, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn06, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(btn02, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn03, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbBola)
                    .addComponent(rbXis)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn01, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn03, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn02, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn04, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn05, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn06, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn07, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn08, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn09, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(rbXis)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbBola)))
                .addGap(26, 26, 26)
                .addComponent(lbmensagem)
                .addContainerGap())
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("..."));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Conectar"));

        btnConectar.setText("Conectar");
        btnConectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConectarActionPerformed(evt);
            }
        });

        btnSair.setText("Sair");
        btnSair.setEnabled(false);
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(btnConectar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSair)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(txtName)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConectar)
                    .addComponent(btnSair)))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Criar Sala"));

        txtSalaNome.setEnabled(false);
        txtSalaNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalaNomeActionPerformed(evt);
            }
        });

        btnSalaCriar.setText("Criar");
        btnSalaCriar.setEnabled(false);
        btnSalaCriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaCriarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtSalaNome, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(btnSalaCriar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(txtSalaNome, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSalaCriar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Salas de Jogo"));

        listSalas.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listSalasValueChanged(evt);
            }
        });
        jScrollPane4.setViewportView(listSalas);

        btnSalaEntrar.setText("Entrar");
        btnSalaEntrar.setEnabled(false);
        btnSalaEntrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaEntrarActionPerformed(evt);
            }
        });

        btnSalaSair.setText("Sair");
        btnSalaSair.setEnabled(false);
        btnSalaSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalaSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSalaEntrar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSalaSair, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSalaEntrar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(btnSalaSair, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnStatus.setEnabled(false);
        btnStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStatusActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Onlines"));

        jScrollPane3.setViewportView(listOnlines);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Rede"));

        txtMultiCastIpGroup.setEditable(false);
        txtMultiCastIpGroup.setText("0");
        txtMultiCastIpGroup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMultiCastIpGroupActionPerformed(evt);
            }
        });

        jLabel1.setText("BroadCast");

        jLabel2.setText("Porta");

        txtMultiCastPorta.setText("0");
        txtMultiCastPorta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMultiCastPortaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtMultiCastIpGroup, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtMultiCastPorta, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMultiCastIpGroup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMultiCastPorta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("..."));

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Mensagem Privada"));

        txtAreaPrivado.setEditable(false);
        txtAreaPrivado.setColumns(20);
        txtAreaPrivado.setRows(5);
        txtAreaPrivado.setEnabled(false);
        jScrollPane5.setViewportView(txtAreaPrivado);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5)
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Mensagem Geral"));

        txtAreaReceive.setEditable(false);
        txtAreaReceive.setColumns(20);
        txtAreaReceive.setRows(5);
        txtAreaReceive.setEnabled(false);
        jScrollPane1.setViewportView(txtAreaReceive);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 248, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Digite uma mensagem"));

        txtAreaSend.setColumns(20);
        txtAreaSend.setRows(5);
        txtAreaSend.setEnabled(false);
        jScrollPane2.setViewportView(txtAreaSend);

        btnLimpar.setText("Limpar");
        btnLimpar.setEnabled(false);
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnEnviar.setText("Enviar");
        btnEnviar.setEnabled(false);
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(btnLimpar)
                .addGap(46, 46, 46)
                .addComponent(btnEnviar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane2)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimpar)
                    .addComponent(btnEnviar)))
        );

        btnStatusJogador.setEnabled(false);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnStatusJogador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStatusJogador, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lbSalaNome.setText("SalaAtual: ");

        btnJogoSair.setText("Sair da Sala");
        btnJogoSair.setEnabled(false);
        btnJogoSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnJogoSairActionPerformed(evt);
            }
        });

        txtSalaAtual.setEditable(false);
        txtSalaAtual.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSalaAtual.setText("X");
        txtSalaAtual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalaAtualActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbSalaNome, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSalaAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(btnJogoSair)))
                .addContainerGap(165, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(lbSalaNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSalaAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnJogoSair)))
                .addContainerGap(78, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void btnConectarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConectarActionPerformed
        String name = txtName.getText();
        if (!name.isEmpty()) {
            this.service = new ClienteService();
            this.message = new ChatMessage();
            this.message.setAction(ChatMessage.Action.CONNECT);
            this.message.setName(name);
            this.message.setText("CONNECTING-TO-SERVER");
            //this.message.setHostIp("localhost");
            this.message.setHostIp(txtMultiCastIpGroup.getText());
            this.message.setHostPorta(this.txtMultiCastPorta.getText());
            this.message.setStatusJogador(Status.DISPONIVEL.toString());
            this.btnStatusJogador.setText(message.getStatusJogador());
            this.txtSalaAtual.setText("");

            System.out.println("ListenerSocket()).start()-> para receber pacotes");

            new Thread(new ListenerSocket()).start();
            this.service.connect(this.message);

        }
    }//GEN-LAST:event_btnConectarActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.service.disconnect(this.message);
        this.btnStatusJogador.setText(Status.INDISPONIVEL.toString());
        disconnected();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        this.txtAreaSend.setText("");
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
        String text = this.txtAreaSend.getText();
        String name = this.message.getName();
        if (!text.isEmpty()) {

            if (this.listOnlines.getSelectedIndex() > -1) {
                String tmp = this.listOnlines.getSelectedValue().toString().replace("-" + Status.DISPONIVEL.toString(), "");
                tmp = tmp.replace("-" + Status.JOGANDO.toString(), "");
                this.message.setNameReserved(tmp);
                this.message.setAction(Action.SEND_PRIVATE);
                System.out.println(this.listOnlines.getSelectedIndex() + " " + this.message.getNameReserved());
                this.listOnlines.clearSelection();
                this.txtAreaPrivado.append("voce disse: " + text + "\n");

            } else {
                this.message.setAction(Action.SEN_ALL);
                this.message.setHostIp(ConstanteMulticast._IP_MULTICAST_);
                this.message.setHostPorta(String.valueOf(ConstanteMulticast._PORTA_MULTICAST_));
                this.txtAreaReceive.append("voce disse: " + text + "\n");
            }

            this.message.setName(name);
            this.message.setText(text);
            this.service.send(this.message);
        }
        this.txtAreaSend.setText("");
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnStatusActionPerformed

    private void btn01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn01ActionPerformed
        setJogadaXisBola(btn01, "1");
    }//GEN-LAST:event_btn01ActionPerformed

    private void btn02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn02ActionPerformed
        setJogadaXisBola(btn02, "2");
    }//GEN-LAST:event_btn02ActionPerformed

    private void btn03ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn03ActionPerformed
        setJogadaXisBola(btn03, "3");
    }//GEN-LAST:event_btn03ActionPerformed

    private void btn04ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn04ActionPerformed
        setJogadaXisBola(btn04, "4");
    }//GEN-LAST:event_btn04ActionPerformed

    private void btn05ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn05ActionPerformed
        setJogadaXisBola(btn05, "5");
    }//GEN-LAST:event_btn05ActionPerformed

    private void btn06ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn06ActionPerformed
        setJogadaXisBola(btn06, "6");
    }//GEN-LAST:event_btn06ActionPerformed

    private void btn07ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn07ActionPerformed
        setJogadaXisBola(btn07, "7");
    }//GEN-LAST:event_btn07ActionPerformed

    private void btn08ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn08ActionPerformed
        setJogadaXisBola(btn08, "8");
    }//GEN-LAST:event_btn08ActionPerformed

    private void btn09ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn09ActionPerformed
        setJogadaXisBola(btn09, "9");
    }//GEN-LAST:event_btn09ActionPerformed

    private void rbXisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbXisActionPerformed
        this.habilitarJogo(true);
        this.habilitaRadioXisBola(false);
    }//GEN-LAST:event_rbXisActionPerformed

    private void btnJogoSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnJogoSairActionPerformed
        this.sairDoJogo();
    }//GEN-LAST:event_btnJogoSairActionPerformed

    private void txtMultiCastIpGroupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMultiCastIpGroupActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMultiCastIpGroupActionPerformed

    private void txtMultiCastPortaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMultiCastPortaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMultiCastPortaActionPerformed

    private void txtSalaNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalaNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalaNomeActionPerformed

    private void btnSalaCriarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaCriarActionPerformed
        String name = txtSalaNome.getText();
        if (!name.isEmpty()) {
            this.message.setAction(ChatMessage.Action.NOVA_SALA);
            this.message.setSalaNew(this.txtSalaNome.getText());
            this.message.setText("CRIANDO-A-SALA");
            this.message.setHostIp(txtMultiCastIpGroup.getText());
            this.message.setHostPorta(this.txtMultiCastPorta.getText());
            this.message.setStatusJogador(Status.JOGANDO.toString());
            this.message.setSalaAtual(this.txtSalaNome.getText());
            this.btnStatusJogador.setText(message.getStatusJogador());
            this.btnSalaCriar.setEnabled(false);
            this.btnSalaEntrar.setEnabled(false);
            this.btnSalaSair.setEnabled(true);
            this.btnJogoSair.setEnabled(true);
            this.txtSalaAtual.setText(message.getSalaNew());
            this.jogoDaVelha = new JogoDaVelha();

            System.out.println("CRIANDO-A-SALA");

            this.service.criandoSala(this.message);
            this.habilitarJogo(false);
            this.habilitaRadioXisBola(false);
            this.limparJogo();

        }
    }//GEN-LAST:event_btnSalaCriarActionPerformed

    private void btnSalaSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaSairActionPerformed

        this.sairDoJogo();

    }//GEN-LAST:event_btnSalaSairActionPerformed

    private void txtSalaAtualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalaAtualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalaAtualActionPerformed

    private void btnSalaEntrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalaEntrarActionPerformed
        lbmensagem.setText("");
        this.limparJogo();
        if (this.listSalas.getSelectedIndex() > -1) {
            String nomeSala = this.listSalas.getSelectedValue().toString().replace("[0/2]-", "");
            nomeSala = nomeSala.replace("[1/2]-", "");
            nomeSala = nomeSala.replace("[2/2]-", "");
            
            if (!this.listSalas.getSelectedValue().toString().contains("[2/2]-")) {
                this.message.setSalaAtual(nomeSala);
                this.message.setAction(Action.ENTRAR_SALA);
                System.out.println(this.listSalas.getSelectedIndex() + " " + nomeSala);
                this.listSalas.clearSelection();

                if (!nomeSala.isEmpty()) {
                    this.message.setStatusJogador(Status.JOGANDO.toString());
                    this.btnStatusJogador.setText(message.getStatusJogador());
                    this.service.entrarSala(this.message);
                    this.btnSalaCriar.setEnabled(false);
                    this.btnSalaEntrar.setEnabled(false);
                    this.btnSalaSair.setEnabled(true);
                    this.btnJogoSair.setEnabled(true);
                    this.txtSalaAtual.setText(nomeSala);
                    this.habilitaRadioXisBola(true);
                    this.jogoDaVelha = new JogoDaVelha();
                }
                
            }else{
                JOptionPane.showMessageDialog(this, "Sala Esta Cheia!");
                this.listSalas.clearSelection();
                this.btnSalaEntrar.setEnabled(false);
            }

        } else {
            System.out.println("\nSelecione uma sala");
        }

    }//GEN-LAST:event_btnSalaEntrarActionPerformed

    private void listSalasValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listSalasValueChanged
        if (this.txtSalaAtual.getText().isEmpty()) {
            this.btnSalaEntrar.setEnabled(true);
        }

    }//GEN-LAST:event_listSalasValueChanged

    private void rbBolaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbBolaActionPerformed
        this.habilitarJogo(true);
        this.habilitaRadioXisBola(false);
    }//GEN-LAST:event_rbBolaActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn01;
    private javax.swing.JButton btn02;
    private javax.swing.JButton btn03;
    private javax.swing.JButton btn04;
    private javax.swing.JButton btn05;
    private javax.swing.JButton btn06;
    private javax.swing.JButton btn07;
    private javax.swing.JButton btn08;
    private javax.swing.JButton btn09;
    private javax.swing.JButton btnConectar;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnJogoSair;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnSair;
    private javax.swing.JButton btnSalaCriar;
    private javax.swing.JButton btnSalaEntrar;
    private javax.swing.JButton btnSalaSair;
    private javax.swing.JButton btnStatus;
    private javax.swing.JButton btnStatusJogador;
    private javax.swing.ButtonGroup groupButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lbSalaNome;
    private javax.swing.JLabel lbmensagem;
    private javax.swing.JList listOnlines;
    private javax.swing.JList listSalas;
    private javax.swing.JRadioButton rbBola;
    private javax.swing.JRadioButton rbXis;
    private javax.swing.JTextArea txtAreaPrivado;
    private javax.swing.JTextArea txtAreaReceive;
    private javax.swing.JTextArea txtAreaSend;
    private javax.swing.JTextField txtMultiCastIpGroup;
    private javax.swing.JTextField txtMultiCastPorta;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtSalaAtual;
    private javax.swing.JTextField txtSalaNome;
    // End of variables declaration//GEN-END:variables

}
