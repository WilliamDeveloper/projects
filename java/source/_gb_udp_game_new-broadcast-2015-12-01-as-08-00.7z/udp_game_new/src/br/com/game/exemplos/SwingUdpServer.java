package br.com.game.exemplos;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import java.io.*;

import java.net.*;

public class SwingUdpServer extends JFrame implements ActionListener {

    JTextField txtfield;
    JTextArea txtarea;
    byte[] sendBytes, receiveBytes;
    DatagramSocket dataSocketClient, dataSocketServer;
    JButton button1;

    public static void main(String[] args) {
        SwingUdpServer server = new SwingUdpServer();
    }

    public SwingUdpServer() {
        this.setSize(300, 300);
        this.setTitle("Server");
        txtfield = new JTextField(100);
        txtfield.setBackground(Color.white);
        txtfield.setForeground(Color.blue);

        this.add(txtfield, BorderLayout.NORTH);
        txtarea = new JTextArea();
        this.add(txtarea, BorderLayout.CENTER);
        txtarea.setBackground(Color.black);
        txtarea.setForeground(Color.green);

        button1 = new JButton("SEND");
        this.add(button1, BorderLayout.SOUTH);
        button1.addActionListener(this);
        this.setVisible(true);
        sendBytes = new byte[1024];
        receiveBytes = new byte[1024];
        //setDefaultCloseOperation(EXIT_ON_CLOSE);	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //*******************************************************************
        try {
            dataSocketClient = new DatagramSocket();
            dataSocketServer = new DatagramSocket(9999);
            while (true) {
                DatagramPacket receiveDataPack = new DatagramPacket(receiveBytes, receiveBytes.length);
                dataSocketServer.receive(receiveDataPack);
                String msg = new String(receiveDataPack.getData());
                txtarea.append("\nClient:" + msg);
            }
        } catch (Exception e) {
        }

    }

    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getActionCommand() == "SEND") {
                String message = txtfield.getText();
                sendBytes = message.getBytes();
                DatagramPacket sendDataPack = new DatagramPacket(sendBytes, sendBytes.length, InetAddress.getLocalHost(), 9998);
                dataSocketClient.send(sendDataPack);
                txtarea.append("\nMyself:" + message);
                txtfield.setText("");
            }
        } catch (Exception a) {
        }
    }

}
