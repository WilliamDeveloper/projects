/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.transfer;

import br.com.game.bean.ChatMessage;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TransferCliente {

    private DatagramSocket clienteDatagramSocket = null;

    public TransferCliente(int porta) {
        try {
            this.clienteDatagramSocket = new DatagramSocket();
        } catch (SocketException ex) {
            Logger.getLogger(TransferCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sp_clienteEnviarPacote(ChatMessage chatMessage) {
        try {
            InetAddress ipAddress = InetAddress.getByName(chatMessage.getHostIp());
            int porta = Integer.parseInt(chatMessage.getHostPorta());
            byte[] sendData = ConvertObject.serialize(chatMessage);
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ipAddress, porta);
            this.clienteDatagramSocket.send(sendPacket);
        } catch (UnknownHostException ex) {
            Logger.getLogger(TransferCliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(TransferCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ChatMessage sf_clienteReceberPacote() {
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        try {
            this.clienteDatagramSocket.receive(receivePacket);
        } catch (IOException ex) {
            Logger.getLogger(TransferCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

        ChatMessage chatMessage = ConvertObject.deserialize(receivePacket.getData(), ChatMessage.class);
        chatMessage.setHostIp(receivePacket.getAddress().getHostAddress());
        chatMessage.setHostPorta(String.valueOf(receivePacket.getPort()));
        return chatMessage;
    }

}