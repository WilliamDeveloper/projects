/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.game.utilitarios;

import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author william
 */
public class BroadCast {

    public static void main(String[] args) throws Exception {
        System.out.println(BroadCast.getBroadCast());       
    }

    public static String getBroadCast() throws SocketException {
        Enumeration<NetworkInterface> interfacesDeRede = NetworkInterface.getNetworkInterfaces();
        while (interfacesDeRede.hasMoreElements()) {
            NetworkInterface ni = interfacesDeRede.nextElement();
            //System.out.println(" Display Name = " + ni.getDisplayName());

            List<InterfaceAddress> list = ni.getInterfaceAddresses();
            Iterator<InterfaceAddress> it = list.iterator();

            while (it.hasNext()) {
                InterfaceAddress ia = it.next();
                //System.out.println(ia.getBroadcast().toString().substring(1)+"+"+ia.getBroadcast().toString().startsWith("127"));
                if (ia.getBroadcast() != null && !ia.getBroadcast().toString().substring(1).startsWith("127")) {
                    //System.out.println(" Broadcast = " + ia.getBroadcast());
                    
                    return ia.getBroadcast().toString().substring(1);
                }
            }
        }
        return null;
    }
}
